<?php
/**
 * @category  BLPaczka
 * @package   BLPaczka\MagentoIntegration
 *
 */

use Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(
    ComponentRegistrar::MODULE,
    'BLPaczka_MagentoIntegration',
    __DIR__
);
