<?php
/**
 * 2007-2024 PrestaShop.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright 2007-2024 PrestaShop SA
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 * International Registered Trademark & Property of PrestaShop SA
 */

namespace PrestaShop\Module\BLPaczka\Dto;

if (!defined('_PS_VERSION_')) {
    exit;
}

use PrestaShop\Module\BLPaczka\Validator\Constraints as AppAssert;
use Symfony\Component\Validator\Constraints as Assert;

class NewBLPaczkaOrderFormDto
{
    /**
     * @var string|null
     *
     * @Assert\NotBlank(message="A payment method for your package is required.", groups={"order"})
     *
     * @Assert\Choice(callback={"PrestaShop\Module\BLPaczka\Enum\PaymentMethodEnum", "getAvailableValues"}, message="The selected payment method is not valid.", groups={"order", "pricing"})
     */
    public $packagePayment;

    /**
     * @var string|null
     *
     * @Assert\NotBlank(message="A parcel courier is required.", groups={"order"})
     *
     * @Assert\Choice(callback={"PrestaShop\Module\BLPaczka\Enum\CourierCodeEnum", "getAvailableValues"}, message="The selected courier is not valid.", groups={"order", "pricing"})
     */
    public $courierCode;

    /**
     * @var string|null
     *
     * @Assert\NotBlank(message="Package type is required.", groups={"order", "pricing"})
     *
     * @Assert\Choice(callback={"PrestaShop\Module\BLPaczka\Enum\ParcelTypeEnum", "getAvailableValues"}, message="The selected package type is not valid.", groups={"order", "pricing"})
     */
    public $parcelType;

    /**
     * @var float|null
     *
     * @Assert\NotBlank(message="Package weight is required.", groups={"order", "pricing"})
     *
     * @Assert\Type(type="numeric", message="Package weight must be a number.", groups={"order", "pricing"})
     *
     * @AppAssert\Positive(message="Package weight must be a positive number.", groups={"order", "pricing"})
     */
    public $packageWeight;

    /**
     * @var float|null
     *
     * @Assert\NotBlank(message="Package length is required.", groups={"order", "pricing"})
     *
     * @Assert\Type(type="numeric", message="Package length must be a number.", groups={"order", "pricing"})
     *
     * @AppAssert\Positive(message="Package length must be a positive number.", groups={"order", "pricing"})
     */
    public $packageLength;

    /**
     * @var float|null
     *
     * @Assert\NotBlank(message="Package width is required.", groups={"order", "pricing"})
     *
     * @Assert\Type(type="numeric", message="Package width must be a number.", groups={"order", "pricing"})
     *
     * @AppAssert\Positive(message="Package width must be a positive number.", groups={"order", "pricing"})
     */
    public $packageWidth;

    /**
     * @var float|null
     *
     * @Assert\NotBlank(message="Package height is required.", groups={"order", "pricing"})
     *
     * @Assert\Type(type="numeric", message="Package height must be a number.", groups={"order", "pricing"})
     *
     * @AppAssert\Positive(message="Package height must be a positive number.", groups={"order", "pricing"})
     */
    public $packageHeight;

    /**
     * @var string|null
     *
     * @Assert\NotBlank(message="Package content description is required.", groups={"order"})
     *
     * @Assert\Type(type="string", message="Content description must be text.", groups={"order"})
     */
    public $packageContent;

    /**
     * @var float
     *            Description: Shipping insurance amount
     *
     * @Assert\Type(type="numeric", message="Package insurance amount must be a number.", groups={"order", "pricing"})
     */
    public $cover;

    /**
     * @var float
     *            Description: Shipping amount with cash on delivery (COD)
     *
     * @Assert\Type(type="numeric", message="COD amount must be a number.", groups={"order", "pricing"})
     */
    public $uptake;

    /**
     * @var bool|null
     *
     * @Assert\Type(type="bool", message="Value must be of boolean type (true or false).", groups={"order", "pricing"})
     */
    public $packageSortable;

    /**
     * @var bool|null
     *
     * @Assert\Type(type="bool", message="Value must be of boolean type (true or false).", groups={"order", "pricing"})
     */
    public $noPickup;

    /**
     * @var string|null
     *
     * @Assert\Date(message="Pickup date must be a valid date.", groups={"order"})
     */
    public $pickupDate;

    /**
     * @var \DateTime|null
     *
     * @Assert\Time(message="Pickup ready time must be a valid time.", groups={"order"})
     */
    public $pickupReadyTime;

    /**
     * @var \DateTime|null
     *
     * @Assert\Time(message="Pickup close time must be a valid time.", groups={"order"})
     */
    public $pickupCloseTime;

    /** SENDER **/

    /**
     * @Assert\NotBlank(message="Sender's name is required.", groups={"order"})
     *
     * @Assert\Length(max=255, maxMessage="Sender's name cannot be longer than 255 characters.", groups={"order"})
     */
    public $senderName;

    /**
     * @Assert\Length(max=255, maxMessage="Sender's company name cannot be longer than 255 characters.", groups={"order"})
     */
    public $senderCompany;

    /**
     * @Assert\NotBlank(message="Sender's email address is required.", groups={"order"})
     *
     * @Assert\Email(message="Sender's email address has an invalid format.", groups={"order"})
     */
    public $senderEmail;

    /**
     * @Assert\Type(type="string", message="Sender's country code must be text.", groups={"order", "pricing"})
     *
     * @Assert\Country(message="Sender's country code has an invalid format.", groups={"order", "pricing"})
     */
    public $senderCountryCode;

    /**
     * @Assert\NotBlank(message="Sender's street is required.", groups={"order"})
     *
     * @Assert\Length(max=255, maxMessage="Sender's street cannot be longer than 255 characters.", groups={"order"})
     */
    public $senderStreet;

    /**
     * @Assert\NotBlank(message="Sender's house number is required.", groups={"order"})
     *
     * @Assert\Length(max=10, maxMessage="Sender's house number cannot be longer than 10 characters.", groups={"order"})
     */
    public $senderHouseNo;

    /**
     * @Assert\Length(max=10, maxMessage="Sender's apartment number cannot be longer than 10 characters.", groups={"order"})
     */
    public $senderLocumNo;

    /**
     * @Assert\NotBlank(message="Sender's postal code is required.", groups={"order", "pricing"})
     *
     * @Assert\Regex(pattern="/^\d{2}-\d{3}$/", message="Sender's postal code has an invalid format.", groups={"order", "pricing"})
     */
    public $senderPostal;

    /**
     * @Assert\NotBlank(message="Sender's city is required.", groups={"order"})
     *
     * @Assert\Length(max=255, maxMessage="Sender's city cannot be longer than 255 characters.", groups={"order"})
     */
    public $senderCity;

    /**
     * @Assert\NotBlank(message="Sender's phone number is required.", groups={"order"})
     *
     * @AppAssert\PhoneNumber(defaultRegion="PL", message="Sender's phone number has an invalid format.", groups={"order"})
     */
    public $senderPhone;

    /**
     * @Assert\NotBlank(message="Sender's account number is required.", groups={"order"})
     *
     * @Assert\Iban(message="Sender's account number has an invalid format.", groups={"order"})
     */
    public $senderAccount;

    /**
     * Point of the sender
     *
     * @var string
     *
     * @Assert\Type(type="string", message="Sender's point must be text.", groups={"order"})
     */
    public $senderPoint;

    /** TAKER **/

    /**
     * Taker name
     *
     * @var string
     *
     * @Assert\NotBlank(message="Recipient's name is required.", groups={"order"})
     *
     * @Assert\Type(type="string", message="Recipient's name must be text.", groups={"order"})
     */
    public $takerName;

    /**
     * Name of the taker's company
     *
     * @var string
     *
     * @Assert\Type(type="string", message="Recipient's company name must be text.", groups={"order"})
     */
    public $takerCompany;

    /**
     * Phone number of the taker
     *
     * @var string
     *
     * @Assert\NotBlank(message="Recipient's phone number is required.", groups={"order"})
     *
     * @Assert\Type(type="string", message="Recipient's phone number must be text.", groups={"order"})
     */
    public $takerPhone;

    /**
     * Street of the taker
     *
     * @var string
     *
     * @Assert\NotBlank(message="Recipient's street is required.", groups={"order"})
     *
     * @Assert\Type(type="string", message="Recipient's street must be text.", groups={"order"})
     */
    public $takerStreet;

    /**
     * Taker city
     *
     * @var string
     *
     * @Assert\NotBlank(message="Recipient's city is required.", groups={"order"})
     *
     * @Assert\Type(type="string", message="Recipient's city must be text.", groups={"order"})
     */
    public $takerCity;

    /**
     * Taker house number
     *
     * @var string
     *
     * @Assert\NotBlank(message="Recipient's house number is required.", groups={"order"})
     *
     * @Assert\Type(type="string", message="Recipient's house number must be text.", groups={"order"})
     */
    public $takerHouseNo;

    /**
     * Taker locum number
     *
     * @var string
     *
     * @Assert\Type(type="string", message="Recipient's apartment number must be text.", groups={"order"})
     */
    public $takerLocumNo;

    /**
     * Taker postal code
     *
     * @var string
     *
     * @Assert\NotBlank(message="Recipient's postal code is required.", groups={"order"})
     *
     * @Assert\Type(type="string", message="Recipient's postal code must be text.", groups={"order"})
     */
    public $takerPostal;

    /**
     * @var string|null
     *
     * @Assert\Country(message="Recipient's country code has an invalid format.", groups={"order", "pricing"})
     */
    public $takerCountryCode;

    /**
     * Email
     *
     * @var string
     *
     * @Assert\NotBlank(message="Recipient's email address is required.", groups={"order"})
     *
     * @Assert\Email(message="Recipient's email address has an invalid format.", groups={"order"})
     */
    public $takerEmail;

    /**
     * Taker email to notify
     *
     * @var string
     *
     * @Assert\Email(message="Recipient's notification email has an invalid format.", groups={"order"})
     */
    public $takerEmailNotify;

    /**
     * Taker email notify message
     *
     * @var string
     *
     * @Assert\Type(type="string", message="Recipient's notification message must be text.", groups={"order"})
     */
    public $takerEmailNotifyMessage;

    /**
     * Point of the delivery
     *
     * @var string
     *
     * @Assert\Type(type="string", message="Delivery point must be text.", groups={"order"})
     */
    public $takerPoint;

    /** CUSTOM PICKUP **/

    /**
     * Pickup at the customer's premises
     *
     * @var bool
     *
     * @Assert\Type(type="bool", message="Value must be of boolean type (true or false).", groups={"order"})
     */
    public $customPickup;

    /**
     * Custom pickup: name
     *
     * @var string
     *
     * @Assert\Type(type="string", message="Pickup point name must be text.", groups={"order"})
     */
    public $pickupName;

    /**
     * Custom pickup: city
     *
     * @var string
     *
     * @Assert\Type(type="string", message="Pickup point city must be text.", groups={"order"})
     */
    public $pickupCity;

    /**
     * Custom pickup: postal
     *
     * @var string
     *
     * @Assert\Type(type="string", message="Pickup point postal code must be text.", groups={"order"})
     */
    public $pickupPostal;

    /**
     * Custom pickup: street
     *
     * @var string
     *
     * @Assert\Type(type="string", message="Pickup point street must be text.", groups={"order"})
     */
    public $pickupStreet;

    /**
     * Custom pickup: house number
     *
     * @var string
     *
     * @Assert\Type(type="string", message="Pickup point house number must be text.", groups={"order"})
     */
    public $pickupHouseNo;

    /**
     * Custom pickup: locum number
     *
     * @var string
     *
     * @Assert\Type(type="string", message="Pickup point apartment number must be text.", groups={"order"})
     */
    public $pickupLocumNo;

    /**
     * Custom pickup: phone number
     *
     * @var string
     *
     * @Assert\Type(type="string", message="Pickup point phone number must be text.", groups={"order"})
     */
    public $pickupPhone;
}
