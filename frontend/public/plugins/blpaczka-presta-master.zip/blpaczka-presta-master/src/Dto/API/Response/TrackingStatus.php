<?php
/**
 * 2007-2024 PrestaShop.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright 2007-2024 PrestaShop SA
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 * International Registered Trademark & Property of PrestaShop SA
 */

namespace PrestaShop\Module\BLPaczka\Dto\API\Response;

if (!defined('_PS_VERSION_')) {
    exit;
}

class TrackingStatus
{
    /** @var string */
    public $status;
    /** @var string */
    public $status_desc;
    /** @var string */
    public $bl_status_mapped;
    /** @var string */
    public $terminal;
    /** @var string */
    public $error_desc;
    /** @var bool */
    public $delivered;
    /** @var string */
    public $received_by;
    /** @var string */
    public $event_time;

    public function __construct($data)
    {
        $this->status = $data['status'] ?? null;
        $this->status_desc = $data['status_desc'] ?? null;
        $this->bl_status_mapped = $data['bl_status_mapped'] ?? null;
        $this->terminal = $data['terminal'] ?? null;
        $this->error_desc = $data['error_desc'] ?? null;
        $this->delivered = isset($data['delivered']) ? (bool) $data['delivered'] : null;
        $this->received_by = $data['received_by'] ?? null;
        $this->event_time = $data['event_time'] ? new \DateTime($data['event_time']) : null;
    }
}
