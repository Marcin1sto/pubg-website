<?php
/**
 * 2007-2024 PrestaShop.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright 2007-2024 PrestaShop SA
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 * International Registered Trademark & Property of PrestaShop SA
 */

namespace PrestaShop\Module\BLPaczka\Dto\API\Response;

if (!defined('_PS_VERSION_')) {
    exit;
}

class CartOrder
{
    /* @var string */
    public $price;

    /* @var bool */
    public $payed;

    /* @var string */
    public $idPrefix;

    /* @var string */
    public $priceNetto;

    /* @var ?string */
    public $paymentUrl;

    /* @var ?string */
    public $paymentStatusDesc;

    public function __construct($data)
    {
        $this->price = isset($data['price']) ? (string) $data['price'] : null;
        $this->payed = isset($data['payed']) ? (bool) $data['payed'] : null;
        $this->idPrefix = isset($data['id_prefix']) ? (string) $data['id_prefix'] : null;
        $this->priceNetto = isset($data['price_netto']) ? (string) $data['price_netto'] : null;
        $this->paymentUrl = isset($data['payment_url']) ? (string) $data['payment_url'] : null;
        $this->paymentStatusDesc = isset($data['payment_status_desc']) ? (string) $data['payment_status_desc'] : null;
    }
}
