<?php
/**
 * 2007-2024 PrestaShop.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright 2007-2024 PrestaShop SA
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 * International Registered Trademark & Property of PrestaShop SA
 */

namespace PrestaShop\Module\BLPaczka\Dto\API\Request;

if (!defined('_PS_VERSION_')) {
    exit;
}

class CourierSearch
{
    /**
     * @var string
     *             Description: Courier code
     */
    public $courierCode;

    /**
     * @var string
     *             Description: Type of parcel
     */
    public $parcelType;

    /**
     * @var string
     *             Description: Foreign type
     */
    public $foreignType;

    /**
     * @var string
     *             Description: Country code in ISO 3166-1 alpha-2 format
     */
    public $countryCode;

    /**
     * @var float
     *            Description: Weight of the order in kg
     */
    public $weight;

    /**
     * @var int
     *          Description: Side X of the order in cm
     */
    public $sideX;

    /**
     * @var int
     *          Description: Side Y of the order in cm
     */
    public $sideY;

    /**
     * @var int
     *          Description: Side Z of the order in cm
     */
    public $sideZ;

    /**
     * @var bool
     *           Description: Sortable
     */
    public $sortable;

    /**
     * @var float
     *            Description: Shipping insurance amount
     */
    public $cover;

    /**
     * @var float
     *            Description: Shipping amount with cash on delivery (COD)
     */
    public $uptake;

    /**
     * @var string
     *             Description: Postal sender
     */
    public $postalSender;

    /**
     * @var string
     *             Description: Postal delivery
     */
    public $postalDelivery;

    /**
     * @var bool
     *           Description: Is delivery to a private address
     */
    public $deliveryPrivate;

    /**
     * @var bool
     *           Description: Is sent from a private address
     */
    public $sendPrivate;

    /**
     * @var bool
     *           Description: Return labels and documents
     */
    public $returnDocs;

    /**
     * @var bool
     *           Description: Pre-Delivery Information telephone number
     */
    public $pdiTel;

    /**
     * @var bool
     *           Description: Is send on Saturday
     */
    public $saturdaySend;

    /**
     * @var bool
     *           Description: Is delivery on Saturday
     */
    public $saturdayDelivery;

    /**
     * @var bool
     *           Description: Is delivery on Sunday
     */
    public $sundayDelivery;

    /**
     * @var bool
     *           Description: Is delivery in the afternoon
     */
    public $afternoonDelivery;

    /**
     * @var bool
     *           Description: Create label synchronous with order? If false, the label will be created in the background
     */
    public $synchronousLabel;

    /**
     * @var string
     *             Description: Is local or foreign
     */
    public $foreign;

    /**
     * @var bool
     *           Description: No Pickup
     */
    public $noPickup;

    /**
     * @var bool
     *           Description: Pickup Notify
     */
    public $pickupNotify;

    /**
     * @var bool
     *           Description: Inpost weekend
     */
    public $inpostWeekend;

    /**
     * @var bool
     *           Description: Is return shipment
     */
    public $isReturn;

    /**
     * @var bool
     *           Description: Is return pallet
     */
    public $returnPallet;

    /**
     * @var bool
     *           Description: Bringing parcel to the door
     */
    public $bringing;

    /**
     * @var bool
     *           Description: Bringing parcel to the door and unpacking
     */
    public $bringingAndUnpack;

    public function toArray()
    {
        return [
            'courier_code' => $this->courierCode,
            'type' => $this->parcelType,
            'foreign_type' => $this->foreignType,
            'country_code' => $this->countryCode,
            'weight' => $this->weight,
            'side_x' => $this->sideX,
            'side_y' => $this->sideY,
            'side_z' => $this->sideZ,
            'sortable' => $this->sortable,
            'cover' => $this->cover,
            'uptake' => $this->uptake,
            'postal_sender' => $this->postalSender,
            'postal_delivery' => $this->postalDelivery,
            'delivery_private' => $this->deliveryPrivate,
            'send_private' => $this->sendPrivate,
            'return_docs' => $this->returnDocs,
            'pdi_tel' => $this->pdiTel,
            'saturday_send' => $this->saturdaySend,
            'saturday_delivery' => $this->saturdayDelivery,
            'sunday_delivery' => $this->sundayDelivery,
            'afternoon_delivery' => $this->afternoonDelivery,
            'synchronous_label' => $this->synchronousLabel,
            'foreign' => $this->foreign,
            'no_pickup' => $this->noPickup,
            'pickup_notify' => $this->pickupNotify,
            'inpost_weekend' => $this->inpostWeekend,
            'is_return' => $this->isReturn,
            'return_pallet' => $this->returnPallet,
            'bringing' => $this->bringing,
            'bringing_and_unpack' => $this->bringingAndUnpack,
            'origin' => 'Prestashop ' . _PS_VERSION_,
        ];
    }
}
