<?php
/**
 * 2007-2024 PrestaShop.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright 2007-2024 PrestaShop SA
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 * International Registered Trademark & Property of PrestaShop SA
 */

namespace PrestaShop\Module\BLPaczka\Dto\API\Request;

if (!defined('_PS_VERSION_')) {
    exit;
}

class Order
{
    /**
     * Name and surname
     *
     * @var string
     */
    public $name;

    /**
     * Name of the sender company
     *
     * @var string
     */
    public $vatCompany;

    /**
     * Email address
     *
     * @var string
     */
    public $email;

    /**
     * Street of the sender
     *
     * @var string
     */
    public $street;

    /**
     * House number
     *
     * @var string
     */
    public $houseNo;

    /**
     * Locum number
     *
     * @var string
     */
    public $locumNo;

    /**
     * Postal code
     *
     * @var string
     */
    public $postal;

    /**
     * City
     *
     * @var string
     */
    public $city;

    /**
     * Phone number
     *
     * @var string
     */
    public $phone;

    /**
     * Account number to which the payment will be made
     *
     * @var string
     */
    public $account;

    /**
     * Taker name
     *
     * @var string
     */
    public $takerName;

    /**
     * Name of the taker's company
     *
     * @var string
     */
    public $takerVatCompany;

    /**
     * Phone number of the taker
     *
     * @var string
     */
    public $takerPhone;

    /**
     * Street of the taker
     *
     * @var string
     */
    public $takerStreet;

    /**
     * Taker city
     *
     * @var string
     */
    public $takerCity;

    /**
     * Taker house number
     *
     * @var string
     */
    public $takerHouseNo;

    /**
     * Taker locum number
     *
     * @var string
     */
    public $takerLocumNo;

    /**
     * Taker postal code
     *
     * @var string
     */
    public $takerPostal;

    /**
     * Email
     *
     * @var string
     */
    public $takerEmail;

    /**
     * Taker email to notify
     *
     * @var string
     */
    public $takerEmailNotify;

    /**
     * Taker email notify message
     *
     * @var string
     */
    public $takerEmailNotifyMessage;

    /**
     * Pickup close time
     *
     * @var string
     */
    public $pickupCloseTime;

    /**
     * Pickup ready time
     *
     * @var string
     */
    public $pickupReadyTime;

    /**
     * Pickup date
     *
     * @var string
     */
    public $pickupDate;

    /**
     * Pickup close time minute
     *
     * @var string
     */
    public $pickupCloseTimeMinute;

    /**
     * Pickup ready time minute
     *
     * @var string
     */
    public $pickupReadyTimeMinute;

    /**
     * Pickup at the customer's premises
     *
     * @var bool
     */
    public $customPickup;

    /**
     * Custom pickup: name
     *
     * @var string
     */
    public $pickupName;

    /**
     * Custom pickup: city
     *
     * @var string
     */
    public $pickupCity;

    /**
     * Custom pickup: postal
     *
     * @var string
     */
    public $pickupPostal;

    /**
     * Custom pickup: street
     *
     * @var string
     */
    public $pickupStreet;

    /**
     * Custom pickup: house number
     *
     * @var string
     */
    public $pickupHouseNo;

    /**
     * Custom pickup: locum number
     *
     * @var string
     */
    public $pickupLocumNo;

    /**
     * Custom pickup: phone number
     *
     * @var string
     */
    public $pickupPhone;

    /**
     * Content of the package
     *
     * @var string
     */
    public $packageContent;

    /**
     * Point of the delivery
     *
     * @var string
     */
    public $takerPoint;

    /**
     * Point of the sender
     *
     * @var string
     */
    public $senderPoint;

    /**
     * Converts the DTO to an associative array with snake_case keys.
     *
     * @return array
     */
    public function toArray()
    {
        return [
            'Order' => [
                'name' => $this->name,
                'vat_company' => $this->vatCompany,
                'email' => $this->email,
                'street' => $this->street,
                'house_no' => $this->houseNo,
                'locum_no' => $this->locumNo,
                'postal' => $this->postal,
                'city' => $this->city,
                'phone' => $this->phone,
                'account' => $this->account,
                'taker_name' => $this->takerName,
                'taker_vat_company' => $this->takerVatCompany,
                'taker_phone' => $this->takerPhone,
                'taker_street' => $this->takerStreet,
                'taker_city' => $this->takerCity,
                'taker_house_no' => $this->takerHouseNo,
                'taker_locum_no' => $this->takerLocumNo,
                'taker_postal' => $this->takerPostal,
                'taker_email' => $this->takerEmail,
                'taker_email_notify' => $this->takerEmailNotify,
                'taker_email_notify_message' => $this->takerEmailNotifyMessage,
                'pickup_close_time' => $this->pickupCloseTime,
                'pickup_ready_time' => $this->pickupReadyTime,
                'pickup_date' => $this->pickupDate,
                'pickup_close_time_minute' => $this->pickupCloseTimeMinute,
                'pickup_ready_time_minute' => $this->pickupReadyTimeMinute,
                'custom_pickup' => $this->customPickup,
                'pickup_name' => $this->pickupName,
                'pickup_city' => $this->pickupCity,
                'pickup_postal' => $this->pickupPostal,
                'pickup_street' => $this->pickupStreet,
                'pickup_house_no' => $this->pickupHouseNo,
                'pickup_locum_no' => $this->pickupLocumNo,
                'pickup_phone' => $this->pickupPhone,
                'package_content' => $this->packageContent,
                'taker_point' => $this->takerPoint,
                'sender_point' => $this->senderPoint,
            ],
        ];
    }
}
