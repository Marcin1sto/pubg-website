<?php
/**
 * 2007-2024 PrestaShop.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright 2007-2024 PrestaShop SA
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 * International Registered Trademark & Property of PrestaShop SA
 */

namespace PrestaShop\Module\BLPaczka\Dto\API\Request;

if (!defined('_PS_VERSION_')) {
    exit;
}

class CreateOrderRequest extends BaseRequest
{
    /**
     * @var CourierSearch
     */
    public $courierSearch;

    /**
     * @var SearchParcel
     */
    public $searchParcel;

    /**
     * @var string
     */
    public $couponCode;

    /**
     * @var CartOrder
     */
    public $paymentMethod;

    /**
     * @var Order[]
     */
    public $orders;

    public function __construct(Auth $auth, CourierSearch $courierSearch, ?SearchParcel $searchParcel, ?string $couponCode, string $paymentMethod, array $orders)
    {
        parent::__construct($auth);
        $this->courierSearch = $courierSearch;
        $this->searchParcel = $searchParcel;
        $this->couponCode = $couponCode;
        $this->paymentMethod = $paymentMethod;
        $this->orders = $orders;
    }

    public function toArray(): array
    {
        return [
            'auth' => $this->auth->toArray(),
            'CourierSearch' => $this->courierSearch->toArray(),
            'SearchParcel' => $this->searchParcel ? $this->searchParcel->toArray() : null,
            'CartCoupon' => $this->couponCode ? ['code' => $this->couponCode] : null,
            'CartOrder' => ['payment' => $this->paymentMethod],
            'Cart' => array_map(
                function (Order $order) {
                    return $order->toArray();
                },
                $this->orders
            ),
        ];
    }
}
