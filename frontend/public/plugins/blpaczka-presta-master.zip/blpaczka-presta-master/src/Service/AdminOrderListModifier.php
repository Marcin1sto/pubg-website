<?php
/**
 * 2007-2024 PrestaShop.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright 2007-2024 PrestaShop SA
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 * International Registered Trademark & Property of PrestaShop SA
 */

namespace PrestaShop\Module\BLPaczka\Service;

if (!defined('_PS_VERSION_')) {
    exit;
}
use PrestaShop\Module\BLPaczka\Model\BlpaczkaOrder;
use PrestaShop\Module\BLPaczka\Traits\Trans;
use PrestaShop\PrestaShop\Core\Grid\Action\Bulk\Type\ButtonBulkAction;
use PrestaShop\PrestaShop\Core\Grid\Action\Bulk\Type\SubmitBulkAction;
use PrestaShop\PrestaShop\Core\Grid\Column\Type\Common\LinkColumn;
use PrestaShop\PrestaShop\Core\Grid\Data\GridData;
use PrestaShop\PrestaShop\Core\Grid\Definition\GridDefinitionInterface;
use PrestaShop\PrestaShop\Core\Grid\Record\RecordCollection;

class AdminOrderListModifier
{
    use Trans;

    /**
     * @var CarrierService
     */
    private $carrierService;

    public function __construct(CarrierService $carrierService)
    {
        $this->carrierService = $carrierService;
    }

    public function modifyColumns($params)
    {
        /** @var GridDefinitionInterface $definition */
        $definition = $params['definition'];

        $definition->getColumns()
            ->addAfter(
                'date_add',
                (new LinkColumn('blpaczka_link'))
                    ->setName('BLPaczka 📦↗️')
                    ->setOptions([
                        'field' => 'blpaczka_link_field',
                        'route' => 'blpaczka_order_grid_single_row_action_route',
                        'route_param_name' => 'orderId',
                        'route_param_field' => 'id_order',
                        'button_template' => 'outline',
                        'color_template' => 'primary',
                    ])
            )
        ;
    }

    public function modifyBulkActions($params)
    {
        /** @var GridDefinitionInterface $definition */
        $definition = $params['definition'];

        $definition->getBulkActions()
            ->add((new SubmitBulkAction('blpaczka_create_orders_bulk_action'))
                ->setName($this->trans('Quick order BLPaczka🚚'))
                ->setOptions([
                    'submit_route' => 'blpaczka_create_order_bulk_action_route',
                ])
            )
            ->add((new ButtonBulkAction('blpaczka_get_waybills_a6_bulk_action'))
                ->setName($this->trans('Download labels BLPaczka📦 - A6[LBL]'))
                ->setOptions([
                    'class' => 'blpaczka-get-waybills-a4-bulk-action',
                ])
            )
            ->add((new ButtonBulkAction('blpaczka_get_waybills_a4_bulk_action'))
                ->setName($this->trans('Download labels BLPaczka📦 - A4'))
                ->setOptions([
                    'class' => 'blpaczka-get-waybills-a6-bulk-action',
                ])
            )
        ;
    }

    public function modifyData($params)
    {
        /** @var GridData $gridData */
        $gridData = $params['data'];
        /** @var RecordCollection $recordCollection */
        $recordCollection = $gridData->getRecords();
        $records = $recordCollection->all();
        $newRecords = [];

        $orderIds = array_map(function ($record) {
            return $record['id_order'];
        }, $records);

        if (!empty($orderIds)) {
            foreach ($records as $key => $record) {
                $orderId = $record['id_order'];

                // Check if order is already ordered in BLPaczka
                $blpaczkaOrder = BlpaczkaOrder::loadByOrderId($orderId);
                if ($blpaczkaOrder && $blpaczkaOrder->blpaczka_order_id) {
                    $record['blpaczka_link_field'] = $this->trans('Order') . ' ✅';
                    $newRecords[$key] = $record;
                    continue;
                }

                // Check if order has carrier mapping
                $mapping = $this->carrierService->getCarrierMappingForOrder($orderId);
                if ($mapping && $mapping->blpaczkaCarrier) {
                    $record['blpaczka_link_field'] = $this->trans('Quick order') . ' - ' . $mapping->blpaczkaCarrier->name . ' 🚚';
                    $newRecords[$key] = $record;
                    continue;
                }

                $record['blpaczka_link_field'] = $this->trans('Define the courier in the settings');
                $newRecords[$key] = $record;
            }
        }

        $params['data'] = new GridData(
            new RecordCollection($newRecords),
            $gridData->getRecordsTotal(),
            $gridData->getQuery()
        );
    }
}
