<?php
/**
 * 2007-2024 PrestaShop.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright 2007-2024 PrestaShop SA
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 * International Registered Trademark & Property of PrestaShop SA
 */

namespace PrestaShop\Module\BLPaczka\Service;

if (!defined('_PS_VERSION_')) {
    exit;
}

use PrestaShop\Module\BLPaczka\Configuration\Repository\ConfigurationRepository;
use PrestaShop\Module\BLPaczka\Dto\API\Request\Auth;
use PrestaShop\Module\BLPaczka\Dto\API\Request\BaseRequest;
use PrestaShop\Module\BLPaczka\Dto\API\Request\CancelOrderRequest;
use PrestaShop\Module\BLPaczka\Dto\API\Request\CourierSearch;
use PrestaShop\Module\BLPaczka\Dto\API\Request\CreateOrderRequest;
use PrestaShop\Module\BLPaczka\Dto\API\Request\DownloadWaybillsMergedRequest;
use PrestaShop\Module\BLPaczka\Dto\API\Request\GetCartOrderStatusRequest;
use PrestaShop\Module\BLPaczka\Dto\API\Request\GetProfileRequest;
use PrestaShop\Module\BLPaczka\Dto\API\Request\GetValuationRequest;
use PrestaShop\Module\BLPaczka\Dto\API\Request\GetWaybillRequest;
use PrestaShop\Module\BLPaczka\Dto\API\Request\GetWaybillTrackingRequest;
use PrestaShop\Module\BLPaczka\Dto\API\Request\Order;
use PrestaShop\Module\BLPaczka\Dto\API\Response\CancelOrderResponse;
use PrestaShop\Module\BLPaczka\Dto\API\Response\CheckConnectionResponse;
use PrestaShop\Module\BLPaczka\Dto\API\Response\CreateOrderResponse;
use PrestaShop\Module\BLPaczka\Dto\API\Response\GetCartOrderStatusResponse;
use PrestaShop\Module\BLPaczka\Dto\API\Response\GetProfileResponse;
use PrestaShop\Module\BLPaczka\Dto\API\Response\GetValuationResponse;
use PrestaShop\Module\BLPaczka\Dto\API\Response\GetWaybillTrackingResponse;
use PrestaShop\Module\BLPaczka\Dto\NewBLPaczkaOrderFormDto;
use PrestaShop\Module\BLPaczka\Enum\ForeignEnum;
use PrestaShop\Module\BLPaczka\Enum\ForeignTypeEnum;

class ApiService
{
    private $baseUrl;
    private $authEmail;
    private $authKey;
    private $sandbox;

    public function __construct(ConfigurationRepository $configurationRepository)
    {
        $authConfig = $configurationRepository->loadAuthConfiguration();
        $this->baseUrl = $this->calcBaseUrl($authConfig->sandbox);
        $this->authEmail = $authConfig->sandbox ? $authConfig->sandboxAuthEmail : $authConfig->authEmail;
        $this->authKey = $authConfig->sandbox ? $authConfig->sandboxAuthKey : $authConfig->authKey;
        $this->sandbox = $authConfig->sandbox;
    }

    public function getMapEndpoint(): string
    {
        $baseUrl =  $this->sandbox ? 'https://sandbox2409.blpaczka.com' : 'https://send.blpaczka.com';
        return $baseUrl . '/pudo-map';
    }

    private function filterNotNull($array)
    {
        $array = array_map(function ($item) {
            return is_array($item) ? $this->filterNotNull($item) : $item;
        }, $array);

        return array_filter($array, function ($item) {
            return $item !== null;
        });
    }

    /**
     * @throws \Exception
     */
    private function postRequest(string $endpoint, BaseRequest $payload, bool $sandbox = null, bool $isJsonResponse = true): array
    {
        $url = $this->baseUrl . $endpoint;

        // Overwrite base URL if sandbox is provided
        if ($sandbox !== null) {
            $url = $this->calcBaseUrl($sandbox) . $endpoint;
        }

        $payload = $payload->toArray();
        $payload = $this->filterNotNull($payload);
        $payloadJson = json_encode($payload);

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payloadJson);

        $rawResponse = curl_exec($ch);
        if (curl_errno($ch)) {
            return [
                'request' => $payload,
                'response' => ['success' => false, 'message' => curl_error($ch), 'data' => []],
            ];
        }

        curl_close($ch);
        $response = $isJsonResponse ? json_decode($rawResponse, true) : $rawResponse;

        if ($response === null && is_string($rawResponse) && !empty($rawResponse)) {
            return [
                'request' => $payload,
                'response' => ['success' => false, 'message' => $rawResponse, 'data' => []],
            ];
        }

        return [
            'request' => $payload,
            'response' => $response,
        ];
    }

    /**
     * @throws \Exception
     */
    public function getProfile(): GetProfileResponse
    {
        $jsonResponse = $this->postRequest(
            '/api/getProfile.json',
            new GetProfileRequest(new Auth($this->authEmail, $this->authKey))
        );

        return new GetProfileResponse($jsonResponse);
    }

    /**
     * @throws \Exception
     */
    public function checkConnection(string $email, string $apiKey, bool $sandbox): CheckConnectionResponse
    {
        $jsonResponse = $this->postRequest(
            '/api/getProfile.json',
            new GetProfileRequest(new Auth($email, $apiKey)),
            $sandbox
        );

        return new CheckConnectionResponse($jsonResponse);
    }

    public function getValuation(NewBLPaczkaOrderFormDto $formData): GetValuationResponse
    {
        $requestDto = new GetValuationRequest(
            new Auth($this->authEmail, $this->authKey),
            $this->makeCourierSearch($formData),
            null
        );

        $jsonResponse = $this->postRequest('/api/getValuation.json', $requestDto);

        return new GetValuationResponse($jsonResponse);
    }

    public function createOrder(NewBLPaczkaOrderFormDto $formData): CreateOrderResponse
    {
        $requestDto = new CreateOrderRequest(
            new Auth($this->authEmail, $this->authKey),
            $this->makeCourierSearch($formData),
            null,
            null,
            $formData->packagePayment,
            [$this->makeOrder($formData)]
        );
        $jsonResponse = $this->postRequest('/api/createOrderV2.json', $requestDto);

        return new CreateOrderResponse($jsonResponse);
    }

    public function getCartOrderStatus(string $idPrefix)
    {
        $requestDto = new GetCartOrderStatusRequest(
            new Auth($this->authEmail, $this->authKey),
            $idPrefix
        );
        $jsonResponse = $this->postRequest('/api/getCartOrderStatus.json', $requestDto);

        return new GetCartOrderStatusResponse($jsonResponse);
    }

    public function getWaybillTracking(int $orderId)
    {
        $requestDto = new GetWaybillTrackingRequest(
            new Auth($this->authEmail, $this->authKey),
            $orderId
        );
        $jsonResponse = $this->postRequest('/api/getWaybillTracking.json', $requestDto);

        return new GetWaybillTrackingResponse($jsonResponse);
    }

    public function downloadWaybillsMerged(array $orderIds, string $format): string
    {
        $requestDto = new DownloadWaybillsMergedRequest(
            new Auth($this->authEmail, $this->authKey),
            $orderIds,
            $format
        );
        $response = $this->postRequest('/api/downloadWaybillsMerged.json', $requestDto, $this->sandbox, false);

        return $response['response'];
    }

    public function getWaybill(int $orderId, string $format): array
    {
        $requestDto = new GetWaybillRequest(
            new Auth($this->authEmail, $this->authKey),
            $orderId,
            $format
        );
        $response = $this->postRequest('/api/getWaybill.json', $requestDto);

        return $response;
    }

    public function cancelOrder(int $orderId): CancelOrderResponse
    {
        $requestDto = new CancelOrderRequest(
            new Auth($this->authEmail, $this->authKey),
            $orderId
        );
        $response = $this->postRequest('/api/cancelOrder.json', $requestDto);

        return new CancelOrderResponse($response);
    }

    private function calcBaseUrl(bool $sandbox)
    {
        return $sandbox ? 'https://sandbox.blpaczka.com' : 'https://send.blpaczka.com';
    }

    private function makeCourierSearch(NewBLPaczkaOrderFormDto $formData): CourierSearch
    {
        $courierSearch = new CourierSearch();

        // courier
        $courierSearch->courierCode = $formData->courierCode;
        $courierSearch->noPickup = $formData->noPickup;

        // package
        $courierSearch->parcelType = $formData->parcelType;
        $courierSearch->weight = $formData->packageWeight;
        $courierSearch->sideX = $formData->packageLength;
        $courierSearch->sideY = $formData->packageWidth;
        $courierSearch->sideZ = $formData->packageHeight;
        $courierSearch->sortable = $formData->packageSortable;
        $courierSearch->cover = $formData->cover;
        $courierSearch->uptake = $formData->uptake;

        // taker
        $courierSearch->countryCode = $formData->takerCountryCode;
        $courierSearch->postalDelivery = $formData->takerPostal;

        // sender
        $courierSearch->postalSender = $formData->senderPostal;

        // international
        $courierSearch->foreignType = $formData->takerCountryCode !== $formData->senderCountryCode ? ForeignTypeEnum::EXPORT : null;
        $courierSearch->foreign = $formData->takerCountryCode !== $formData->senderCountryCode ? ForeignEnum::FOREIGN : ForeignEnum::LOCAL;

        // todo
        $courierSearch->pickupNotify = null; // todo
        $courierSearch->sendPrivate = null; // todo
        $courierSearch->deliveryPrivate = null; // todo
        $courierSearch->returnDocs = null; // todo
        $courierSearch->pdiTel = null; // todo
        $courierSearch->saturdaySend = null; // todo
        $courierSearch->saturdayDelivery = null; // todo
        $courierSearch->sundayDelivery = null; // todo
        $courierSearch->afternoonDelivery = null; // todo
        $courierSearch->synchronousLabel = false; // todo
        $courierSearch->inpostWeekend = null; // todo
        $courierSearch->isReturn = null; // todo
        $courierSearch->returnPallet = null; // todo
        $courierSearch->bringing = null; // todo
        $courierSearch->bringingAndUnpack = null; // todo

        return $courierSearch;
    }

    private function makeOrder(NewBLPaczkaOrderFormDto $formData): Order
    {
        $order = new Order();

        $order->packageContent = $formData->packageContent;

        // sender
        $order->name = $formData->senderName;
        $order->vatCompany = $formData->senderCompany;
        $order->email = $formData->senderEmail;
        $order->street = $formData->senderStreet;
        $order->houseNo = $formData->senderHouseNo;
        $order->locumNo = $formData->senderLocumNo;
        $order->postal = $formData->senderPostal;
        $order->city = $formData->senderCity;
        $order->phone = preg_replace('/[^\d+]+/', '', $formData->senderPhone);
        $order->account = $formData->senderAccount;
        $order->senderPoint = $formData->senderPoint;

        // taker
        $order->takerPoint = $formData->takerPoint;
        $order->takerName = $formData->takerName;
        $order->takerVatCompany = $formData->takerCompany;
        $order->takerPhone = preg_replace('/[^\d+]+/', '', $formData->takerPhone);
        $order->takerStreet = $formData->takerStreet;
        $order->takerCity = $formData->takerCity;
        $order->takerHouseNo = $formData->takerHouseNo;
        $order->takerLocumNo = $formData->takerLocumNo;
        $order->takerPostal = $formData->takerPostal;
        $order->takerEmail = $formData->takerEmail;
        $order->takerEmailNotify = $formData->takerEmailNotify;
        $order->takerEmailNotifyMessage = $formData->takerEmailNotifyMessage;

        // custom pickup
        $order->pickupDate = $formData->pickupDate ? $formData->pickupDate->format('Y-m-d') : null;
        if ($formData->pickupCloseTime) {
            $order->pickupCloseTime = $formData->pickupCloseTime->format('H');
            $order->pickupCloseTimeMinute = $formData->pickupCloseTime->format('i');
        }
        if ($formData->pickupReadyTime) {
            $order->pickupReadyTime = $formData->pickupReadyTime->format('H');
            $order->pickupReadyTimeMinute = $formData->pickupReadyTime->format('i');
        }
        $order->customPickup = (bool) $formData->customPickup;
        $order->pickupName = $formData->pickupName;
        $order->pickupCity = $formData->pickupCity;
        $order->pickupPostal = $formData->pickupPostal;
        $order->pickupStreet = $formData->pickupStreet;
        $order->pickupHouseNo = $formData->pickupHouseNo;
        $order->pickupLocumNo = $formData->pickupLocumNo;
        $order->pickupPhone = preg_replace('/[^\d+]+/', '', $formData->pickupPhone ?? $formData->takerPhone);

        return $order;
    }
}
