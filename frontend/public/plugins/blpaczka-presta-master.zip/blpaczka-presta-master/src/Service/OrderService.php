<?php
/**
 * 2007-2024 PrestaShop.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright 2007-2024 PrestaShop SA
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 * International Registered Trademark & Property of PrestaShop SA
 */

namespace PrestaShop\Module\BLPaczka\Service;

if (!defined('_PS_VERSION_')) {
    exit;
}

use PrestaShop\Module\BLPaczka\Dto\API\Response\CancelOrderResponse;
use PrestaShop\Module\BLPaczka\Dto\API\Response\CreateOrderResponse;
use PrestaShop\Module\BLPaczka\Model\BlpaczkaOrder;

class OrderService
{
    /** @var \Db */
    private $db;

    /** @var CardService */
    private $cardService;

    public function __construct(CardService $cardService)
    {
        $this->db = \Db::getInstance();
        $this->cardService = $cardService;
    }

    public function handleCreateOrderResponse(int $orderId, CreateOrderResponse $response): ?BlpaczkaOrder
    {
        if (!$response->success) {
            return null;
        }

        $blpaczkaOrder = BlpaczkaOrder::loadByOrderId($orderId);
        if (!$blpaczkaOrder) {
            $blpaczkaOrder = new BlpaczkaOrder();
            $blpaczkaOrder->order_id = $orderId;
            $blpaczkaOrder->pudo_code = $orderFormDto->pudoCode ?? 'NONE';
            $blpaczkaOrder->api_type = $orderFormDto->courierCode ?? 'NONE';
        }
        $blpaczkaOrder->waybill_link = $response->waybillLink;
        $blpaczkaOrder->id_prefix = $response->cartOrder->idPrefix;
        $blpaczkaOrder->price = $response->cartOrder->price;
        $blpaczkaOrder->price_netto = $response->cartOrder->priceNetto;
        $blpaczkaOrder->payment_url = $response->cartOrder->paymentUrl;
        $blpaczkaOrder->waybill_no = $response->order->waybillNo;
        $blpaczkaOrder->blpaczka_order_id = (string) $response->order->id;
        $blpaczkaOrder->blpaczka_order_name = $response->order->name;
        $blpaczkaOrder->raw_request = $response->rawRequest;
        $blpaczkaOrder->raw_response = $response->rawResponse;
        $blpaczkaOrder->save();

        $order = new \Order($orderId);
        $orderCarrier = new \OrderCarrier($order->getIdOrderCarrier());
        $orderCarrier->tracking_number = $response->order->waybillNo;
        $orderCarrier->update();

        $history = new \OrderHistory();
        $history->id_order = $orderId;
        $history->id_employee = \Context::getContext()->employee->id;
        $history->changeIdOrderState(4, $orderId, true);
        $history->add();

        return $blpaczkaOrder;
    }

    public function handleCancelOrderResponse(int $orderId, CancelOrderResponse $response): bool
    {
        if ($response->success && $blpaczkaOrder = BlpaczkaOrder::loadByOrderId($orderId)) {
            $blpaczkaOrder->waybill_link = null;
            $blpaczkaOrder->id_prefix = null;
            $blpaczkaOrder->price = null;
            $blpaczkaOrder->price_netto = null;
            $blpaczkaOrder->payment_url = null;
            $blpaczkaOrder->waybill_no = null;
            $blpaczkaOrder->blpaczka_order_id = null;
            $blpaczkaOrder->blpaczka_order_name = null;
            $blpaczkaOrder->raw_request = null;
            $blpaczkaOrder->raw_response = null;

            $order = new \Order($orderId);
            $orderCarrier = new \OrderCarrier($order->getIdOrderCarrier());
            $orderCarrier->tracking_number = null;

            return $blpaczkaOrder->save(true) && $orderCarrier->update();
        }

        return false;
    }

    // Todo: can be moved to BlpaczkaOrder model
    public function saveOrderData(int $cardId, int $orderId)
    {
        $row = $this->cardService->getCardData($cardId);
        if ($row) {
            $this->db->insert('blpaczka_order', [
                'order_id' => pSQL($orderId),
                'pudo_code' => pSQL($row['pudo_code']),
                'api_type' => pSQL($row['api_type']),
            ]);
        }
    }

    // Todo: can be moved to BlpaczkaOrder model
    public function getPudoCode(int $orderId, string $apiType): ?string
    {
        $pudoCode = $this->db->getValue('SELECT pudo_code FROM ' . _DB_PREFIX_ . 'blpaczka_order WHERE order_id = ' . pSQL($orderId) . ' AND api_type = "' . pSQL($apiType) . '"');

        return $pudoCode ?: null;
    }
}
