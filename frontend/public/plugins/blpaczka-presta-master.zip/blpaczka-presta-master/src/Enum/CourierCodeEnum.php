<?php
/**
 * 2007-2024 PrestaShop.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright 2007-2024 PrestaShop SA
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 * International Registered Trademark & Property of PrestaShop SA
 */

namespace PrestaShop\Module\BLPaczka\Enum;

if (!defined('_PS_VERSION_')) {
    exit;
}

class CourierCodeEnum
{
    const DPD = 'dpd';
    const ALLEGRO_SMART_DPD = 'allegro_smart_dpd';
    const UPS = 'ups';
    const DHL = 'dhl';
    const BLP_CROSS_BORDER = 'blp_cross_border';
    const BLP_CROSS_BORDER_ECO = 'blp_cross_border_eco';
    const FEDEX = 'fedex';
    const FEDEX_REST = 'fedex_rest';
    const GLS = 'gls';
    const GEIS = 'geis';
    const GEODIS = 'geodis';
    const HELLMAN = 'hellman';
    const INPOST = 'inpost';
    const INPOST_INTERNATIONAL = 'inpost_international';
    const ORLEN = 'orlen';
    const PACZKOMATY = 'paczkomaty';
    const PACZKOMATY_ALLEGRO_SMART = 'paczkomaty_allegro_smart';
    const PACZKOMATY_ECO = 'paczkomaty_eco';
    const POCZTA = 'poczta';
    const POCZTA_ECOMMERCE_ENVELOPE = 'poczta_ecommerce_envelope';
    const ALLEGRO_SMART_ECOMMERCE = 'allegro_smart_ecommerce';
    const ALLEGRO_SMART_POCZTA = 'allegro_smart_poczta';
    const PACZKOMATY_TO_DOOR = 'paczkomaty_to_door';
    const EURO_HERMES = 'euro_hermes';
    const OLZA_LOGISTIC = 'olza_logistic';
    const AMBRO_EXPRESS = 'ambro_express';
    const SPRING = 'spring';

    public static function getAvailableValues()
    {
        return [
            self::DPD,
            self::ALLEGRO_SMART_DPD,
            self::UPS,
            self::DHL,
            self::BLP_CROSS_BORDER,
            self::BLP_CROSS_BORDER_ECO,
            self::FEDEX,
            self::FEDEX_REST,
            self::GLS,
            self::GEIS,
            self::GEODIS,
            self::HELLMAN,
            self::INPOST,
            self::INPOST_INTERNATIONAL,
            self::ORLEN,
            self::PACZKOMATY,
            self::PACZKOMATY_ALLEGRO_SMART,
            self::PACZKOMATY_ECO,
            self::POCZTA,
            self::POCZTA_ECOMMERCE_ENVELOPE,
            self::ALLEGRO_SMART_ECOMMERCE,
            self::ALLEGRO_SMART_POCZTA,
            self::PACZKOMATY_TO_DOOR,
            self::EURO_HERMES,
            self::OLZA_LOGISTIC,
            self::AMBRO_EXPRESS,
            self::SPRING,
        ];
    }
}
