<?php
/**
 * 2007-2024 PrestaShop.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright 2007-2024 PrestaShop SA
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 * International Registered Trademark & Property of PrestaShop SA
 */

namespace PrestaShop\Module\BLPaczka\Model;

if (!defined('_PS_VERSION_')) {
    exit;
}

use PrestaShop\Module\BLPaczka\Dto\API\Response\TrackingStatus;

class BlpaczkaTrackingStatus extends \ObjectModel
{
    public $id_blpaczka_tracking_status;
    public $blpaczka_order_id;
    public $status;
    public $status_desc;
    public $bl_status_mapped;
    public $terminal;
    public $error_desc;
    public $delivered;
    public $received_by;
    public $event_time;

    public static $definition = [
        'table' => 'blpaczka_tracking_status',
        'primary' => 'id_blpaczka_tracking_status',
        'fields' => [
            'blpaczka_order_id' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required' => true],
            'status' => ['type' => self::TYPE_STRING, 'validate' => 'isString', 'required' => true, 'size' => 50],
            'status_desc' => ['type' => self::TYPE_STRING, 'validate' => 'isString', 'required' => false, 'size' => 255],
            'bl_status_mapped' => ['type' => self::TYPE_STRING, 'validate' => 'isString', 'required' => true, 'size' => 50],
            'terminal' => ['type' => self::TYPE_STRING, 'validate' => 'isString', 'size' => 255],
            'error_desc' => ['type' => self::TYPE_STRING, 'validate' => 'isString', 'size' => 1023],
            'delivered' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool'],
            'received_by' => ['type' => self::TYPE_STRING, 'validate' => 'isString', 'size' => 255],
            'event_time' => ['type' => self::TYPE_DATE, 'validate' => 'isDateFormat', 'required' => true],
        ],
    ];

    public static function createIfNotExist(TrackingStatus $trackingStatus): self
    {
        $sql = new \DbQuery();
        $sql->select(self::$definition['primary']);
        $sql->from(self::$definition['table']);
        $sql->where('status = \'' . pSQL($trackingStatus->status) . '\'');
        $sql->where('bl_status_mapped = \'' . pSQL($trackingStatus->bl_status_mapped) . '\'');
        $sql->where('event_time = \'' . pSQL($trackingStatus->event_time->format('Y-m-d H:i:s')) . '\'');

        $id = \Db::getInstance()->getValue($sql);

        if ($id) {
            return new self($id);
        }

        $dto = new self();
        $dto->status = $trackingStatus->status;
        $dto->status_desc = $trackingStatus->status_desc;
        $dto->bl_status_mapped = $trackingStatus->bl_status_mapped;
        $dto->terminal = $trackingStatus->terminal;
        $dto->error_desc = $trackingStatus->error_desc;
        $dto->delivered = $trackingStatus->delivered;
        $dto->received_by = $trackingStatus->received_by;
        $dto->event_time = $trackingStatus->event_time->format('Y-m-d H:i:s');
        $dto->add();

        return $dto;
    }

    public static function loadAllByBlpaczkaOrderId(int $blpaczkaOrderId): array
    {
        $sql = new \DbQuery();
        $sql->select('*');
        $sql->from(self::$definition['table']);
        $sql->where('blpaczka_order_id = ' . $blpaczkaOrderId);

        $rows = \Db::getInstance()->executeS($sql);

        $dtos = [];
        foreach ($rows as $row) {
            $dto = new self();
            $dto->hydrate($row);
            $dtos[] = $dto;
        }

        return $dtos;
    }
}
