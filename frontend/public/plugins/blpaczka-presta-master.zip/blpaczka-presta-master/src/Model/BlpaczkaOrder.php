<?php
/**
 * 2007-2024 PrestaShop.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright 2007-2024 PrestaShop SA
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 * International Registered Trademark & Property of PrestaShop SA
 */

namespace PrestaShop\Module\BLPaczka\Model;

if (!defined('_PS_VERSION_')) {
    exit;
}

class BlpaczkaOrder extends \ObjectModel
{
    public $id_blpaczka_order;
    public $order_id;
    public $pudo_code;
    public $api_type;
    public $waybill_link;
    public $id_prefix;
    public $price;
    public $price_netto;
    public $payment_url;
    public $waybill_no;
    public $blpaczka_order_id;
    public $blpaczka_order_name;
    public $raw_request;
    public $raw_response;

    public static $definition = [
        'table' => 'blpaczka_order',
        'primary' => 'id_blpaczka_order',
        'fields' => [
            'order_id' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required' => true],
            'pudo_code' => ['type' => self::TYPE_STRING, 'validate' => 'isString', 'required' => true, 'size' => 255],
            'api_type' => ['type' => self::TYPE_STRING, 'validate' => 'isString', 'required' => true, 'size' => 255],
            'waybill_link' => ['type' => self::TYPE_STRING, 'validate' => 'isUrl', 'size' => 1023],
            'id_prefix' => ['type' => self::TYPE_STRING, 'validate' => 'isString', 'size' => 50],
            'price' => ['type' => self::TYPE_FLOAT, 'validate' => 'isPrice'],
            'price_netto' => ['type' => self::TYPE_FLOAT, 'validate' => 'isPrice'],
            'payment_url' => ['type' => self::TYPE_STRING, 'validate' => 'isUrl', 'size' => 1023],
            'waybill_no' => ['type' => self::TYPE_STRING, 'validate' => 'isString', 'size' => 255],
            'blpaczka_order_id' => ['type' => self::TYPE_STRING, 'validate' => 'isString', 'size' => 50],
            'blpaczka_order_name' => ['type' => self::TYPE_STRING, 'validate' => 'isString', 'size' => 255],
            'raw_request' => ['type' => self::TYPE_STRING, 'validate' => 'isString'],
            'raw_response' => ['type' => self::TYPE_STRING, 'validate' => 'isString'],
        ],
    ];

    public function __construct($id_blpaczka_order = null, $id_lang = null, $id_shop = null)
    {
        parent::__construct($id_blpaczka_order, $id_lang, $id_shop);
        if ($this->raw_response) {
            $this->raw_response = json_decode($this->raw_response, true);
        }
        if ($this->raw_request) {
            $this->raw_request = json_decode($this->raw_request, true);
        }
    }

    public static function loadByOrderId(int $orderId): ?self
    {
        $sql = new \DbQuery();
        $sql->select(self::$definition['primary']);
        $sql->from(self::$definition['table']);
        $sql->where('order_id = ' . $orderId);

        $id = \Db::getInstance()->getValue($sql);

        if ($id) {
            return new self($id);
        }

        return null;
    }

    public function save($null_values = false, $auto_date = true)
    {
        if (is_array($this->raw_response)) {
            $this->raw_response = json_encode($this->raw_response);
        }
        if (is_array($this->raw_request)) {
            $this->raw_request = json_encode($this->raw_request);
        }

        return parent::save($null_values, $auto_date);
    }
}
