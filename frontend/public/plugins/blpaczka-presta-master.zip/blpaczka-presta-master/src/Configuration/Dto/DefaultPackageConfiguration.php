<?php
/**
 * 2007-2024 PrestaShop.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright 2007-2024 PrestaShop SA
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 * International Registered Trademark & Property of PrestaShop SA
 */

namespace PrestaShop\Module\BLPaczka\Configuration\Dto;

if (!defined('_PS_VERSION_')) {
    exit;
}

use PrestaShop\Module\BLPaczka\Validator\Constraints as AppAssert;
use Symfony\Component\Validator\Constraints as Assert;

class DefaultPackageConfiguration implements ConfigurationInterface
{
    /**
     * @var float|null
     *
     * @Assert\NotBlank(message="Package weight is required.")
     *
     * @Assert\Type(type="numeric", message="Package weight must be a number.")
     *
     * @AppAssert\Positive(message="Package weight must be a positive number.")
     */
    public $packageWeight;

    /**
     * @var float|null
     *
     * @Assert\NotBlank(message="Package length is required.")
     *
     * @Assert\Type(type="numeric", message="Package length must be a number.")
     *
     * @AppAssert\Positive(message="Package length must be a positive number.")
     */
    public $packageLength;

    /**
     * @var float|null
     *
     * @Assert\NotBlank(message="Package width is required.")
     *
     * @Assert\Type(type="numeric", message="Package width must be a number.")
     *
     * @AppAssert\Positive(message="Package width must be a positive number.")
     */
    public $packageWidth;

    /**
     * @var float|null
     *
     * @Assert\NotBlank(message="Package height is required.")
     *
     * @Assert\Type(type="numeric", message="Package height must be a number.")
     *
     * @AppAssert\Positive(message="Package height must be a positive number.")
     */
    public $packageHeight;

    /**
     * @var string|null
     *
     * @Assert\NotBlank(message="Package content description is required.")
     *
     * @Assert\Type(type="string", message="Content description must be text.")
     */
    public $packageContent;

    /**
     * @var bool|null
     *
     * @Assert\Type(type="bool", message="The value must be of boolean type (true or false).")
     */
    public $packageSortable;

    /**
     * @var bool|null
     *
     * @Assert\Type(type="bool", message="The value must be of boolean type (true or false).")
     */
    public $packageNoPickup;

    /**
     * @var int|null
     *
     * @Assert\NotBlank(message="Package pickup delay is required.")
     *
     * @Assert\Type(type="numeric", message="Package pickup delay must be a number.")
     *
     * @AppAssert\Positive(message="Package pickup delay must be a positive number.")
     */
    public $pickupDateDelay;

    /**
     * @var string|null
     *
     * @Assert\Time(message="Ready for pickup time must be a valid time.")
     */
    public $pickupReadyTime;

    /**
     * @var string|null
     *
     * @Assert\Time(message="Pickup close time must be a valid time.")
     */
    public $pickupCloseTime;

    /**
     * @var string|null
     *
     * @Assert\NotBlank(message="Package type is required.")
     */
    public $packageType;

    /**
     * @var string|null
     *
     * @Assert\NotBlank(message="Package courier is required.")
     */
    public $packageCourier;

    /**
     * @var string|null
     *
     * @Assert\NotBlank(message="Package payment method is required.")
     *
     * @Assert\Choice(callback={"PrestaShop\Module\BLPaczka\Enum\PaymentMethodEnum", "getAvailableValues"}, message="The selected payment method is not valid.")
     */
    public $packagePayment;

    public $printFormat;
}
