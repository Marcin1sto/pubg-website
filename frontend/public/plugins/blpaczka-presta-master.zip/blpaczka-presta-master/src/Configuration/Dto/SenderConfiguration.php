<?php
/**
 * 2007-2024 PrestaShop.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright 2007-2024 PrestaShop SA
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 * International Registered Trademark & Property of PrestaShop SA
 */

namespace PrestaShop\Module\BLPaczka\Configuration\Dto;

if (!defined('_PS_VERSION_')) {
    exit;
}

use PrestaShop\Module\BLPaczka\Validator\Constraints as AppAssert;
use Symfony\Component\Validator\Constraints as Assert;

class SenderConfiguration implements ConfigurationInterface
{
    /**
     * @Assert\NotBlank(message="Sender's name is required.")
     *
     * @Assert\Length(max=255, maxMessage="Sender's name cannot exceed 255 characters.")
     */
    public $senderName;

    /**
     * @Assert\Length(max=255, maxMessage="Sender's company name cannot exceed 255 characters.")
     */
    public $senderCompany;

    /**
     * @Assert\NotBlank(message="Sender's email address is required.")
     *
     * @Assert\Email(message="Sender's email address has an invalid format.")
     */
    public $senderEmail;

    /**
     * @Assert\NotBlank(message="Sender's street is required.")
     *
     * @Assert\Length(max=255, maxMessage="Sender's street cannot exceed 255 characters.")
     */
    public $senderStreet;

    /**
     * @Assert\NotBlank(message="Sender's house number is required.")
     *
     * @Assert\Length(max=10, maxMessage="Sender's house number cannot exceed 10 characters.")
     */
    public $senderHouseNo;

    /**
     * @Assert\Length(max=10, maxMessage="Sender's apartment number cannot exceed 10 characters.")
     */
    public $senderLocumNo;

    /**
     * @Assert\NotBlank(message="Sender's postal code is required.")
     *
     * @Assert\Regex(pattern="/^\d{2}-\d{3}$/", message="Sender's postal code has an invalid format.")
     */
    public $senderPostal;

    /**
     * @Assert\NotBlank(message="Sender's city is required.")
     *
     * @Assert\Length(max=255, maxMessage="Sender's city cannot exceed 255 characters.")
     */
    public $senderCity;

    /**
     * @Assert\NotBlank(message="Sender's country code is required.")
     *
     * @Assert\Country(message="Sender's country code has an invalid format.")
     */
    public $senderCountryCode;

    /**
     * @Assert\NotBlank(message="Sender's phone number is required.")
     *
     * @AppAssert\PhoneNumber(defaultRegion="PL", message="Sender's phone number has an invalid format.")
     */
    public $senderPhone;

    /**
     * @Assert\NotBlank(message="Sender's account number is required.")
     *
     * @Assert\Iban(message="Sender's account number has an invalid format.")
     */
    public $senderAccount;
}
