<?php
/**
 * 2007-2024 PrestaShop.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright 2007-2024 PrestaShop SA
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 * International Registered Trademark & Property of PrestaShop SA
 */

namespace PrestaShop\Module\BLPaczka\Configuration\Repository;

if (!defined('_PS_VERSION_')) {
    exit;
}

use PrestaShop\Module\BLPaczka\Configuration\Configs;
use PrestaShop\Module\BLPaczka\Configuration\Dto\AuthConfiguration;
use PrestaShop\Module\BLPaczka\Configuration\Dto\CarrierMappingConfiguration;
use PrestaShop\Module\BLPaczka\Configuration\Dto\CarrierMappingDto;
use PrestaShop\Module\BLPaczka\Configuration\Dto\DefaultPackageConfiguration;
use PrestaShop\Module\BLPaczka\Configuration\Dto\SenderConfiguration;
use PrestaShop\Module\BLPaczka\Repository\CarrierRepository;

class ConfigurationRepository
{
    /** @var CarrierRepository */
    private $carrierRepository;

    public function __construct(CarrierRepository $carrierRepository)
    {
        $this->carrierRepository = $carrierRepository;
    }

    public function loadAuthConfiguration(): AuthConfiguration
    {
        $authEmail = \Configuration::get(Configs::AUTH_EMAIL);
        $authKey = \Configuration::get(Configs::AUTH_KEY);
        $authEmailSandbox = \Configuration::get(Configs::AUTH_EMAIL_SANDBOX);
        $authKeySandbox = \Configuration::get(Configs::AUTH_KEY_SANDBOX);
        $sandbox = \Configuration::get(Configs::AUTH_SANDBOX);

        $dto = new AuthConfiguration();

        $dto->authEmail = empty($authEmail) ? null : $authEmail;
        $dto->authKey = empty($authKey) ? null : $authKey;
        $dto->sandboxAuthEmail = empty($authEmailSandbox) ? null : $authEmailSandbox;
        $dto->sandboxAuthKey = empty($authKeySandbox) ? null : $authKeySandbox;
        $dto->sandbox = (bool) $sandbox;

        return $dto;
    }

    public function saveAuthConfiguration(AuthConfiguration $dto): void
    {
        \Configuration::updateValue(Configs::AUTH_EMAIL, $dto->authEmail);
        \Configuration::updateValue(Configs::AUTH_KEY, $dto->authKey);
        \Configuration::updateValue(Configs::AUTH_EMAIL_SANDBOX, $dto->sandboxAuthEmail);
        \Configuration::updateValue(Configs::AUTH_KEY_SANDBOX, $dto->sandboxAuthKey);
        \Configuration::updateValue(Configs::AUTH_SANDBOX, (bool) $dto->sandbox);
    }

    public function loadDefaultPackageConfiguration(): DefaultPackageConfiguration
    {
        $packageWeight = \Configuration::get(Configs::PACKAGE_WEIGHT);
        $packageLength = \Configuration::get(Configs::PACKAGE_LENGTH);
        $packageWidth = \Configuration::get(Configs::PACKAGE_WIDTH);
        $packageHeight = \Configuration::get(Configs::PACKAGE_HEIGHT);
        $packageContent = \Configuration::get(Configs::PACKAGE_CONTENT);
        $packageSortable = \Configuration::get(Configs::PACKAGE_SORTABLE);
        $packageNoPickup = \Configuration::get(Configs::PACKAGE_NO_PICKUP);
        $pickupDateDelay = \Configuration::get(Configs::PACKAGE_PICKUP_DATE_DELAY);
        $pickupReadyTime = \Configuration::get(Configs::PACKAGE_PICKUP_READY_TIME);
        $pickupCloseTime = \Configuration::get(Configs::PACKAGE_PICKUP_CLOSE_TIME);
        $packageType = \Configuration::get(Configs::PACKAGE_TYPE);
        $packageCourier = \Configuration::get(Configs::PACKAGE_COURIER);
        $packagePayment = \Configuration::get(Configs::PACKAGE_PAYMENT);
        $printFormat = \Configuration::get(Configs::PRINT_FORMAT);

        $dto = new DefaultPackageConfiguration();

        $dto->packageWeight = empty($packageWeight) ? null : $packageWeight;
        $dto->packageLength = empty($packageLength) ? null : $packageLength;
        $dto->packageWidth = empty($packageWidth) ? null : $packageWidth;
        $dto->packageHeight = empty($packageHeight) ? null : $packageHeight;
        $dto->packageContent = empty($packageContent) ? null : $packageContent;
        $dto->packageSortable = (bool) $packageSortable;
        $dto->packageNoPickup = (bool) $packageNoPickup;
        $dto->pickupDateDelay = empty($pickupDateDelay) ? null : $pickupDateDelay;
        $dto->pickupReadyTime = empty($pickupReadyTime) ? null : new \DateTime($pickupReadyTime);
        $dto->pickupCloseTime = empty($pickupCloseTime) ? null : new \DateTime($pickupCloseTime);
        $dto->packageType = empty($packageType) ? null : $packageType;
        $dto->packageCourier = empty($packageCourier) ? null : $packageCourier;
        $dto->packagePayment = empty($packagePayment) ? null : $packagePayment;
        $dto->printFormat = empty($printFormat) ? null : $printFormat;

        return $dto;
    }

    public function saveDefaultPackageConfiguration(DefaultPackageConfiguration $dto): void
    {
        \Configuration::updateValue(Configs::PACKAGE_WEIGHT, $dto->packageWeight);
        \Configuration::updateValue(Configs::PACKAGE_LENGTH, $dto->packageLength);
        \Configuration::updateValue(Configs::PACKAGE_WIDTH, $dto->packageWidth);
        \Configuration::updateValue(Configs::PACKAGE_HEIGHT, $dto->packageHeight);
        \Configuration::updateValue(Configs::PACKAGE_CONTENT, $dto->packageContent);
        \Configuration::updateValue(Configs::PACKAGE_SORTABLE, (bool) $dto->packageSortable);
        \Configuration::updateValue(Configs::PACKAGE_NO_PICKUP, (bool) $dto->packageNoPickup);
        \Configuration::updateValue(Configs::PACKAGE_PICKUP_DATE_DELAY, $dto->pickupDateDelay);
        \Configuration::updateValue(Configs::PACKAGE_PICKUP_READY_TIME, $dto->pickupReadyTime ? $dto->pickupReadyTime->format('H:i') : null);
        \Configuration::updateValue(Configs::PACKAGE_PICKUP_CLOSE_TIME, $dto->pickupCloseTime ? $dto->pickupCloseTime->format('H:i') : null);
        \Configuration::updateValue(Configs::PACKAGE_TYPE, $dto->packageType);
        \Configuration::updateValue(Configs::PACKAGE_COURIER, $dto->packageCourier);
        \Configuration::updateValue(Configs::PACKAGE_PAYMENT, $dto->packagePayment);
        \Configuration::updateValue(Configs::PRINT_FORMAT, $dto->printFormat);
    }

    public function loadSenderConfiguration(): SenderConfiguration
    {
        $senderName = \Configuration::get(Configs::SENDER_NAME);
        $senderCompany = \Configuration::get(Configs::SENDER_COMPANY);
        $senderEmail = \Configuration::get(Configs::SENDER_EMAIL);
        $senderStreet = \Configuration::get(Configs::SENDER_STREET);
        $senderHouseNo = \Configuration::get(Configs::SENDER_HOUSE_NO);
        $senderLocumNo = \Configuration::get(Configs::SENDER_LOCUM_NO);
        $senderPostal = \Configuration::get(Configs::SENDER_POSTAL);
        $senderCity = \Configuration::get(Configs::SENDER_CITY);
        $senderCountryCode = \Configuration::get(Configs::SENDER_COUNTRY_CODE);
        $senderPhone = \Configuration::get(Configs::SENDER_PHONE);
        $senderAccount = \Configuration::get(Configs::SENDER_ACCOUNT);

        $dto = new SenderConfiguration();

        $dto->senderName = empty($senderName) ? null : $senderName;
        $dto->senderCompany = empty($senderCompany) ? null : $senderCompany;
        $dto->senderEmail = empty($senderEmail) ? null : $senderEmail;
        $dto->senderStreet = empty($senderStreet) ? null : $senderStreet;
        $dto->senderHouseNo = empty($senderHouseNo) ? null : $senderHouseNo;
        $dto->senderLocumNo = empty($senderLocumNo) ? null : $senderLocumNo;
        $dto->senderPostal = empty($senderPostal) ? null : $senderPostal;
        $dto->senderCity = empty($senderCity) ? null : $senderCity;
        $dto->senderCountryCode = empty($senderCountryCode) ? 'PL' : $senderCountryCode;
        $dto->senderPhone = empty($senderPhone) ? null : $senderPhone;
        $dto->senderAccount = empty($senderAccount) ? null : $senderAccount;

        return $dto;
    }

    public function saveSenderConfiguration(SenderConfiguration $dto): void
    {
        \Configuration::updateValue(Configs::SENDER_NAME, $dto->senderName);
        \Configuration::updateValue(Configs::SENDER_COMPANY, $dto->senderCompany);
        \Configuration::updateValue(Configs::SENDER_EMAIL, $dto->senderEmail);
        \Configuration::updateValue(Configs::SENDER_STREET, $dto->senderStreet);
        \Configuration::updateValue(Configs::SENDER_HOUSE_NO, $dto->senderHouseNo);
        \Configuration::updateValue(Configs::SENDER_LOCUM_NO, $dto->senderLocumNo);
        \Configuration::updateValue(Configs::SENDER_POSTAL, $dto->senderPostal);
        \Configuration::updateValue(Configs::SENDER_CITY, $dto->senderCity);
        \Configuration::updateValue(Configs::SENDER_COUNTRY_CODE, $dto->senderCountryCode);
        \Configuration::updateValue(Configs::SENDER_PHONE, $dto->senderPhone);
        \Configuration::updateValue(Configs::SENDER_ACCOUNT, $dto->senderAccount);
    }

    public function loadCarrierMappingConfiguration(): CarrierMappingConfiguration
    {
        /**
         * JOSN mapping structure:
         * [
         *    '$prestashopCarrierId' => ['code' => '$blpaczkaCarrierCode', 'show_map' => true|false],
         *    (...)
         * ]
         */
        $mappingJsonRaw = \Configuration::get(Configs::CARRIER_MAPPING);
        $mappingJson = json_decode($mappingJsonRaw ? $mappingJsonRaw : '[]', true);

        $blpaczkaCarriersByCode = array_column($this->carrierRepository->getAllBLPaczkaCarriers(), null, 'code');
        $dto = new CarrierMappingConfiguration();

        foreach ($this->carrierRepository->getAllPrestashopCarriers() as $prestashopCarrier) {
            $blpaczkaCarrier = null;
            $showMap = null;

            if (array_key_exists($prestashopCarrier->id, $mappingJson)) {
                $mapping = $mappingJson[$prestashopCarrier->id];
                $code = $mapping['code'];

                // override $blpaczkaCarrier and $showMap if mapping exists
                if ($code && array_key_exists($code, $blpaczkaCarriersByCode)) {
                    $blpaczkaCarrier = $blpaczkaCarriersByCode[$code];
                    $showMap = $this->overrideShowMapIfNeeded($code, (bool) ($mapping['show_map'] ?? false));
                }
            }

            $dto->mapping[] = new CarrierMappingDto(
                $prestashopCarrier,
                $blpaczkaCarrier,
                $showMap
            );
        }

        return $dto;
    }

    public function saveCarrierMappingConfiguration(CarrierMappingConfiguration $dto): void
    {
        $mappingJson = [];
        foreach ($dto->mapping as $mapping) {
            $code = $mapping->blpaczkaCarrier ? $mapping->blpaczkaCarrier->code : null;
            $showMap = $this->overrideShowMapIfNeeded($code, $mapping->showMap);
            $mappingJson[$mapping->prestashopCarrier->id] = [
                'code' => $code,
                'show_map' => $showMap,
            ];
        }

        \Configuration::updateValue(Configs::CARRIER_MAPPING, json_encode($mappingJson));
    }

    public function overrideShowMapIfNeeded(?string $code, bool $showMap): bool
    {
        $blpaczkaCarriersByCode = array_column($this->carrierRepository->getAllBLPaczkaCarriers(), null, 'code');
        if (array_key_exists($code, $blpaczkaCarriersByCode)) {
            $blpaczkaCarrier = $blpaczkaCarriersByCode[$code];
            if ($blpaczkaCarrier->isRequired()) {
                return true;
            } elseif ($blpaczkaCarrier->isNoMap()) {
                return false;
            }
        }

        return $showMap;
    }
}
