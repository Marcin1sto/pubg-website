<?php
/**
 * 2007-2024 PrestaShop.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright 2007-2024 PrestaShop SA
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 * International Registered Trademark & Property of PrestaShop SA
 */

namespace PrestaShop\Module\BLPaczka\Configuration\Form;

if (!defined('_PS_VERSION_')) {
    exit;
}

use PrestaShop\Module\BLPaczka\Configuration\Dto\AuthConfiguration;
use PrestaShop\Module\BLPaczka\Traits\Trans;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ButtonType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class AuthConfigurationType extends AbstractType
{
    use Trans;

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('authEmail', EmailType::class, [
                'label' => $this->trans('Email'),
                'help' => $this->trans('Enter your login email used to create an account in BLPaczka'),
                'required' => false,
                'attr' => [
                    'class' => 'form-control',
                ],
            ])
            ->add('authKey', PasswordType::class, [
                'label' => $this->trans('API Key'),
                'help' => $this->trans('Enter the API key from the account editing tab'),
                'required' => false,
                'attr' => [
                    'class' => 'form-control',
                ],
            ])
            ->add('sandboxAuthEmail', EmailType::class, [
                'label' => $this->trans('Email for Sandbox Mode'),
                'help' => $this->trans('Enter your login email used to create an account in BLPaczka'),
                'required' => false,
                'attr' => [
                    'class' => 'form-control',
                ],
            ])
            ->add('sandboxAuthKey', PasswordType::class, [
                'label' => $this->trans('API Key for Sandbox Mode'),
                'help' => $this->trans('Enter the API key from the account editing tab'),
                'required' => false,
                'attr' => [
                    'class' => 'form-control',
                ],
            ])
            ->add('sandbox', CheckboxType::class, [
                'label' => $this->trans('Sandbox Mode'),
                'help' => $this->trans('Check to enable Sandbox Mode for testing'),
                'required' => false,
                'attr' => [
                    'class' => 'form-check-input',
                ],
            ])
            ->add('check_connection', ButtonType::class, [
                'label' => $this->trans('Check Connection'),
                'attr' => [
                    'class' => 'btn btn-primary',
                    'onclick' => 'checkBLPaczkaApiConnection()',
                ],
            ])
        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => AuthConfiguration::class,
            'validation_groups' => function (FormInterface $form) {
                if ($form->get('sandbox')->getData()) {
                    return ['sandbox'];
                }

                return ['production'];
            },
        ]);
    }
}
