<?php
/**
 * 2007-2024 PrestaShop.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright 2007-2024 PrestaShop SA
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 * International Registered Trademark & Property of PrestaShop SA
 */

namespace PrestaShop\Module\BLPaczka\Configuration\Form;

if (!defined('_PS_VERSION_')) {
    exit;
}

use PrestaShop\Module\BLPaczka\Configuration\Dto\SenderConfiguration;
use PrestaShop\Module\BLPaczka\Traits\Trans;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class SenderConfigurationType extends AbstractType
{
    use Trans;

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('senderName', TextType::class, [
                'label' => $this->trans('Full Name'),
                'help' => $this->trans('Enter the sender\'s full name'),
                'required' => false,
            ])
            ->add('senderCompany', TextType::class, [
                'label' => $this->trans('Company Name'),
                'help' => $this->trans('Enter the sender\'s company name'),
                'required' => false,
            ])
            ->add('senderEmail', EmailType::class, [
                'label' => $this->trans('Email Address'),
                'help' => $this->trans('Enter the sender\'s email address'),
                'required' => false,
            ])
            ->add('senderStreet', TextType::class, [
                'label' => $this->trans('Street'),
                'help' => $this->trans('Enter the sender\'s street'),
                'required' => false,
            ])
            ->add('senderHouseNo', TextType::class, [
                'label' => $this->trans('House Number'),
                'help' => $this->trans('Enter the sender\'s house number'),
                'required' => false,
            ])
            ->add('senderLocumNo', TextType::class, [
                'label' => $this->trans('Apartment Number'),
                'help' => $this->trans('Enter the sender\'s apartment number'),
                'required' => false,
            ])
            ->add('senderPostal', TextType::class, [
                'label' => $this->trans('Postal Code'),
                'help' => $this->trans('Enter the sender\'s postal code'),
                'required' => false,
            ])
            ->add('senderCity', TextType::class, [
                'label' => $this->trans('City'),
                'help' => $this->trans('Enter the sender\'s city'),
                'required' => false,
            ])
            ->add('senderCountryCode', TextType::class, [
                'label' => $this->trans('Sender Country'),
                'required' => true,
            ])
            ->add('senderPhone', TextType::class, [
                'label' => $this->trans('Phone Number'),
                'help' => $this->trans('Enter the sender\'s phone number'),
                'required' => false,
            ])
            ->add('senderAccount', TextType::class, [
                'label' => $this->trans('Account Number for Cash on Delivery Returns'),
                'help' => $this->trans('Enter the account number for cash on delivery returns'),
                'required' => false,
            ]);
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => SenderConfiguration::class,
        ]);
    }
}
