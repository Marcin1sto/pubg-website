<?php
/**
 * 2007-2024 PrestaShop.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright 2007-2024 PrestaShop SA
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 * International Registered Trademark & Property of PrestaShop SA
 */

namespace PrestaShop\Module\BLPaczka\Configuration\Form;

if (!defined('_PS_VERSION_')) {
    exit;
}

use PrestaShop\Module\BLPaczka\Configuration\Dto\DefaultPackageConfiguration;
use PrestaShop\Module\BLPaczka\Dto\BLPaczkaCurrierDto;
use PrestaShop\Module\BLPaczka\Enum\ParcelTypeEnum;
use PrestaShop\Module\BLPaczka\Enum\PaymentMethodEnum;
use PrestaShop\Module\BLPaczka\Enum\PrintFormatEnum;
use PrestaShop\Module\BLPaczka\Traits\Trans;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TimeType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class DefaultPackageConfigurationType extends AbstractType
{
    use Trans;

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        /* @var BLPaczkaCurrierDto[] $packageCourierOptions */
        $packageCourierOptions = $options['blpaczkaCarriers'];

        $builder
            ->add('packageWeight', TextType::class, [
                'label' => $this->trans('Package weight'),
                'help' => $this->trans('Enter package weight'),
                'required' => false,
            ])
            ->add('packageLength', TextType::class, [
                'label' => $this->trans('Package length'),
                'help' => $this->trans('Enter package length'),
                'required' => false,
            ])
            ->add('packageWidth', TextType::class, [
                'label' => $this->trans('Package width'),
                'help' => $this->trans('Enter package width'),
                'required' => false,
            ])
            ->add('packageHeight', TextType::class, [
                'label' => $this->trans('Package height'),
                'help' => $this->trans('Enter package height'),
                'required' => false,
            ])
            ->add('packageContent', TextType::class, [
                'label' => $this->trans('Package content'),
                'help' => $this->trans('Enter package content'),
                'required' => false,
            ])
            ->add('packageSortable', CheckboxType::class, [
                'label' => $this->trans('Sortable package'),
                'help' => $this->trans('Is the package sortable?'),
                'required' => false,
            ])
            ->add('packageNoPickup', CheckboxType::class, [
                'label' => $this->trans('No pickup request'),
                'help' => $this->trans('Do not request a pickup'),
                'required' => false,
            ])
            ->add('pickupDateDelay', NumberType::class, [
                'label' => $this->trans('Courier arrival in (days)'),
                'help' => $this->trans('The default courier arrival date is the open order date + the number of days set in this field'),
                'required' => false,
            ])
            ->add('pickupReadyTime', TimeType::class, [
                'label' => $this->trans('Courier can arrive from (time)'),
                'help' => $this->trans('Enter the time from which the courier can arrive'),
                'widget' => 'single_text',
                'required' => false,
            ])
            ->add('pickupCloseTime', TimeType::class, [
                'label' => $this->trans('Courier can arrive until (time)'),
                'help' => $this->trans('Enter the time until which the courier can arrive'),
                'widget' => 'single_text',
                'required' => false,
            ])
            ->add('packageType', ChoiceType::class, [
                'label' => $this->trans('Package type'),
                'choices' => [
                    $this->trans('Package') => ParcelTypeEnum::PACKAGE,
                    $this->trans('Pallet') => ParcelTypeEnum::PALLET,
                    $this->trans('Envelope') => ParcelTypeEnum::ENVELOPE,
                ],
                'help' => $this->trans('Select the package type'),
                'required' => false,
            ])
            ->add('packageCourier', ChoiceType::class, [
                'label' => $this->trans('Default courier'),
                'choices' => array_combine(
                    array_map(
                        function ($currier) {
                            return $currier->name;
                        },
                        $packageCourierOptions
                    ),
                    array_map(
                        function ($currier) {
                            return $currier->code;
                        },
                        $packageCourierOptions
                    )
                ),
                'help' => $this->trans('Select the default courier'),
                'required' => false,
            ])
            ->add('packagePayment', ChoiceType::class, [
                'label' => $this->trans('Payment method'),
                'choices' => [
                    $this->trans('Piggy bank') => PaymentMethodEnum::BANK,
                    $this->trans('Deferred payment') => PaymentMethodEnum::PAY_LATER,
                ],
                'help' => $this->trans('Select the payment method'),
                'required' => false,
            ])
            ->add('printFormat', ChoiceType::class, [
                'label' => $this->trans('Label format'),
                'choices' => [
                    $this->trans('A6 (LBL)') => PrintFormatEnum::LBL,
                    $this->trans('A4') => PrintFormatEnum::A4,
                    $this->trans('ZPL') => PrintFormatEnum::ZPL,
                    $this->trans('EPL') => PrintFormatEnum::EPL,
                ],
                'help' => $this->trans('Select the label format'),
                'required' => false,
            ]);
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver
            ->setDefaults([
                'data_class' => DefaultPackageConfiguration::class,
            ])
            ->setRequired([
                'blpaczkaCarriers',
            ]);
    }
}
