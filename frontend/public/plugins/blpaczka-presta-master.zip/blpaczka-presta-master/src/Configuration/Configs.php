<?php
/**
 * 2007-2024 PrestaShop.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright 2007-2024 PrestaShop SA
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 * International Registered Trademark & Property of PrestaShop SA
 */

namespace PrestaShop\Module\BLPaczka\Configuration;

if (!defined('_PS_VERSION_')) {
    exit;
}

class Configs
{
    const AUTH_EMAIL = 'BLPACZKA_AUTH_EMAIL';
    const AUTH_KEY = 'BLPACZKA_AUTH_KEY';
    const AUTH_EMAIL_SANDBOX = 'BLPACZKA_AUTH_EMAIL_SANDBOX';
    const AUTH_KEY_SANDBOX = 'BLPACZKA_AUTH_KEY_SANDBOX';
    const AUTH_SANDBOX = 'BLPACZKA_AUTH_SANDBOX';

    const SENDER_NAME = 'BLPACZKA_SENDER_NAME';
    const SENDER_COMPANY = 'BLPACZKA_SENDER_COMPANY';
    const SENDER_EMAIL = 'BLPACZKA_SENDER_EMAIL';
    const SENDER_STREET = 'BLPACZKA_SENDER_STREET';
    const SENDER_HOUSE_NO = 'BLPACZKA_SENDER_HOUSE_NO';
    const SENDER_LOCUM_NO = 'BLPACZKA_SENDER_LOCUM_NO';
    const SENDER_POSTAL = 'BLPACZKA_SENDER_POSTAL';
    const SENDER_CITY = 'BLPACZKA_SENDER_CITY';
    const SENDER_COUNTRY_CODE = 'BLPACZKA_SENDER_COUNTRY_CODE';
    const SENDER_PHONE = 'BLPACZKA_SENDER_PHONE';
    const SENDER_ACCOUNT = 'BLPACZKA_SENDER_ACCOUNT';

    const PACKAGE_WEIGHT = 'BLPACZKA_PACKAGE_WEIGHT';
    const PACKAGE_LENGTH = 'BLPACZKA_PACKAGE_LENGTH';
    const PACKAGE_WIDTH = 'BLPACZKA_PACKAGE_WIDTH';
    const PACKAGE_HEIGHT = 'BLPACZKA_PACKAGE_HEIGHT';
    const PACKAGE_CONTENT = 'BLPACZKA_PACKAGE_CONTENT';
    const PACKAGE_SORTABLE = 'BLPACZKA_PACKAGE_SORTABLE';
    const PACKAGE_NO_PICKUP = 'BLPACZKA_PACKAGE_NO_PICKUP';
    const PACKAGE_PICKUP_DATE_DELAY = 'BLPACZKA_PACKAGE_PICKUP_DATE_DELAY';
    const PACKAGE_PICKUP_READY_TIME = 'BLPACZKA_PACKAGE_PICKUP_READY_TIME';
    const PACKAGE_PICKUP_CLOSE_TIME = 'BLPACZKA_PACKAGE_PICKUP_CLOSE_TIME';
    const PACKAGE_TYPE = 'BLPACZKA_PACKAGE_TYPE';
    const PACKAGE_COURIER = 'BLPACZKA_PACKAGE_COURIER';
    const PACKAGE_PAYMENT = 'BLPACZKA_PACKAGE_PAYMENT';
    const PRINT_FORMAT = 'BLPACZKA_PRINT_FORMAT';

    const CARRIER_MAPPING = 'BLPACZKA_CARRIER_MAPPING';

    public static function getAllConfigurationKeys()
    {
        // reflection
        $reflection = new \ReflectionClass(__CLASS__);

        return array_values($reflection->getConstants());
    }
}
