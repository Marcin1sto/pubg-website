<?php
/**
 * 2007-2024 PrestaShop.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright 2007-2024 PrestaShop SA
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 * International Registered Trademark & Property of PrestaShop SA
 */

namespace PrestaShop\Module\BLPaczka\Form;

if (!defined('_PS_VERSION_')) {
    exit;
}

use PrestaShop\Module\BLPaczka\Dto\BLPaczkaCurrierDto;
use PrestaShop\Module\BLPaczka\Dto\NewBLPaczkaOrderFormDto;
use PrestaShop\Module\BLPaczka\Enum\ParcelTypeEnum;
use PrestaShop\Module\BLPaczka\Enum\PaymentMethodEnum;
use PrestaShop\Module\BLPaczka\Traits\Trans;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TimeType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class NewBLPaczkaOrderType extends AbstractType
{
    use Trans;

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        /* @var BLPaczkaCurrierDto[] $packageCourierOptions */
        $packageCourierOptions = $options['blpaczkaCarriers'];

        /* @var callable $preSubmitDataModifier */
        $preSubmitDataModifier = $options['preSubmitDataModifier'];

        $builder
            ->add('packagePayment', ChoiceType::class, [
                'label' => $this->trans('Payment method'),
                'placeholder' => $this->trans('No selected'),
                'choices' => [
                    $this->trans('Skarbonka') => PaymentMethodEnum::BANK,
                    $this->trans('Deferred payment') => PaymentMethodEnum::PAY_LATER,
                ],
                'help' => $this->trans('Select payment method'),
                'required' => false,
            ])
            // Kurier
            ->add('courierCode', ChoiceType::class, [
                'label' => $this->trans('Carrier'),
                'placeholder' => $this->trans('Any'),
                'choices' => array_combine(
                    array_map(
                        function ($currier) {
                            return $currier->name;
                        },
                        $packageCourierOptions
                    ),
                    array_map(
                        function ($currier) {
                            return $currier->code;
                        },
                        $packageCourierOptions
                    )
                ),
                'required' => false,
            ])
            ->add('noPickup', CheckboxType::class, [
                'label' => $this->trans('Do not order a pick-up'),
                'help' => $this->trans('Do not order a courier for pick-up'),
                'required' => false,
            ])
            ->add('pickupDate', DateType::class, [
                'label' => $this->trans('Date when the courier can pick up'),
                'widget' => 'single_text',
                'required' => false,
            ])
            ->add('pickupReadyTime', TimeType::class, [
                'label' => $this->trans('Time when the courier can pick up'),
                'help' => $this->trans('Enter the time when the courier can pick up'),
                'widget' => 'single_text',
                'required' => false,
            ])
            ->add('pickupCloseTime', TimeType::class, [
                'label' => $this->trans('Time until the courier can pick up'),
                'help' => $this->trans('Enter the time until the courier can pick up'),
                'widget' => 'single_text',
                'required' => false,
            ])
            // Paczka
            ->add('parcelType', ChoiceType::class, [
                'label' => $this->trans('Parcel type'),
                'choices' => [
                    $this->trans('Package') => ParcelTypeEnum::PACKAGE,
                    $this->trans('Pallet') => ParcelTypeEnum::PALLET,
                    $this->trans('Envelop') => ParcelTypeEnum::ENVELOPE,
                ],
                'help' => $this->trans('Select parcel type'),
                'required' => false,
            ])
            ->add('packageWeight', TextType::class, [
                'label' => $this->trans('Package weight'),
                'help' => $this->trans('Enter the weight of the package'),
                'required' => false,
            ])
            ->add('packageLength', TextType::class, [
                'label' => $this->trans('Package length'),
                'help' => $this->trans('Enter the length of the package'),
                'required' => false,
            ])
            ->add('packageWidth', TextType::class, [
                'label' => $this->trans('Package width'),
                'help' => $this->trans('Enter the width of the package'),
                'required' => false,
            ])
            ->add('packageHeight', TextType::class, [
                'label' => $this->trans('Package height'),
                'help' => $this->trans('Enter the height of the package'),
                'required' => false,
            ])
            ->add('packageContent', TextType::class, [
                'label' => $this->trans('Package content'),
                'help' => $this->trans('Enter the content of the package'),
                'required' => false,
            ])
            ->add('cover', TextType::class, [
                'label' => $this->trans('Insurance (in PLN)'),
                'required' => false,
            ])
            ->add('uptake', TextType::class, [
                'label' => $this->trans('Cash on delivery (in PLN)'),
                'required' => false,
            ])
            ->add('packageSortable', CheckboxType::class, [
                'label' => $this->trans('Sortable parcel'),
                'help' => $this->trans('Check if the package is sortable'),
                'required' => false,
            ])
            // Taker
            ->add('takerPoint', TextType::class, [
                'label' => $this->trans('Pick-up point'),
                'help' => $this->trans('Enter the pick-up point (double-click to open the map)'),
                'required' => false,
            ])
            ->add('takerName', TextType::class, [
                'label' => $this->trans('Name and surname'),
                'help' => $this->trans('Enter the name and surname of the recipient'),
                'required' => false,
            ])
            ->add('takerCompany', TextType::class, [
                'label' => $this->trans('Company name'),
                'help' => $this->trans('Enter the name of the recipient company'),
                'required' => false,
            ])
            ->add('takerPhone', TextType::class, [
                'label' => $this->trans('Phone number'),
                'help' => $this->trans('Enter the recipient\'s phone number'),
                'required' => false,
            ])
            ->add('takerEmail', EmailType::class, [
                'label' => $this->trans('Email address'),
                'help' => $this->trans('Enter the recipient\'s email address'),
                'required' => false,
            ])
            ->add('takerEmailNotify', EmailType::class, [
                'label' => $this->trans('Email address for notifications'),
                'help' => $this->trans('Enter the recipient\'s email address for notifications'),
                'required' => false,
            ])
            ->add('takerEmailNotifyMessage', TextType::class, [
                'label' => $this->trans('Notification message'),
                'help' => $this->trans('Enter the message for the recipient'),
                'required' => false,
            ])
            ->add('takerStreet', TextType::class, [
                'label' => $this->trans('Street'),
                'help' => $this->trans('Enter the recipient\'s street'),
                'required' => false,
            ])
            ->add('takerHouseNo', TextType::class, [
                'label' => $this->trans('House number'),
                'help' => $this->trans('Enter the recipient\'s house number'),
                'required' => false,
            ])
            ->add('takerLocumNo', TextType::class, [
                'label' => $this->trans('Apartment number'),
                'help' => $this->trans('Enter the recipient\'s apartment number'),
                'required' => false,
            ])
            ->add('takerPostal', TextType::class, [
                'label' => $this->trans('Postal code'),
                'help' => $this->trans('Enter the recipient\'s postal code'),
                'required' => false,
            ])
            ->add('takerCity', TextType::class, [
                'label' => $this->trans('City'),
                'help' => $this->trans('Enter the recipient\'s city'),
                'required' => false,
            ])
            ->add('takerCountryCode', TextType::class, [
                'label' => $this->trans('Recipient\'s country'),
                'required' => false,
            ])
            // Sender
            ->add('senderName', TextType::class, [
                'label' => $this->trans('Name and surname'),
                'help' => $this->trans('Enter the name and surname of the sender'),
                'required' => false,
            ])
            ->add('senderCompany', TextType::class, [
                'label' => $this->trans('Company name'),
                'help' => $this->trans('Enter the name of the sender company'),
                'required' => false,
            ])
            ->add('senderPhone', TextType::class, [
                'label' => $this->trans('Phone number'),
                'help' => $this->trans('Enter the sender\'s phone number'),
                'required' => false,
            ])
            ->add('senderEmail', EmailType::class, [
                'label' => $this->trans('Email address'),
                'help' => $this->trans('Enter the sender\'s email address'),
                'required' => false,
            ])
            ->add('senderStreet', TextType::class, [
                'label' => $this->trans('Street'),
                'help' => $this->trans('Enter the sender\'s street'),
                'required' => false,
            ])
            ->add('senderHouseNo', TextType::class, [
                'label' => $this->trans('House number'),
                'help' => $this->trans('Enter the sender\'s house number'),
                'required' => false,
            ])
            ->add('senderLocumNo', TextType::class, [
                'label' => $this->trans('Apartment number'),
                'help' => $this->trans('Enter the sender\'s apartment number'),
                'required' => false,
            ])
            ->add('senderPostal', TextType::class, [
                'label' => $this->trans('Postal code'),
                'help' => $this->trans('Enter the sender\'s postal code'),
                'required' => false,
            ])
            ->add('senderCity', TextType::class, [
                'label' => $this->trans('City'),
                'help' => $this->trans('Enter the sender\'s city'),
                'required' => false,
            ])
            ->add('senderCountryCode', TextType::class, [
                'label' => $this->trans('Sender\'s country'),
                'required' => false,
            ])
            // Buttons
            ->add('pricing', SubmitType::class, [
                'label' => $this->trans('Calculate the price'),
                'attr' => ['class' => 'btn-primary'],
            ])
            ->add('order', SubmitType::class, [
                'label' => $this->trans('Send a parcel'),
                'attr' => ['class' => 'btn-primary'],
            ])
        ;

        $builder->addEventListener(FormEvents::PRE_SUBMIT, function (FormEvent $event) use ($preSubmitDataModifier) {
            $data = $event->getData();
            $data = $preSubmitDataModifier($data);
            $event->setData($data);
        });
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver
            ->setDefaults([
                'data_class' => NewBLPaczkaOrderFormDto::class,
                'validation_groups' => function (FormInterface $form) {
                    if ($form->get('order')->isClicked()) {
                        return ['order'];
                    } elseif ($form->get('pricing')->isClicked()) {
                        return ['pricing'];
                    }

                    return ['Default'];
                },
                'preSubmitDataModifier' => function ($data) {
                    return $data;
                },
            ])
            ->setRequired([
                'blpaczkaCarriers',
            ]);
    }
}
