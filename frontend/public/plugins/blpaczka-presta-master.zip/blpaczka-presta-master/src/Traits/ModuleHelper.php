<?php
/**
 * 2007-2024 PrestaShop.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright 2007-2024 PrestaShop SA
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 * International Registered Trademark & Property of PrestaShop SA
 */

namespace PrestaShop\Module\BLPaczka\Traits;

if (!defined('_PS_VERSION_')) {
    exit;
}

use PrestaShop\Module\BLPaczka\Configuration\Repository\ConfigurationRepository;
use PrestaShop\Module\BLPaczka\Factory\OrderFormDtoFactory;
use PrestaShop\Module\BLPaczka\Repository\CarrierRepository;
use PrestaShop\Module\BLPaczka\Service\AdminOrderListModifier;
use PrestaShop\Module\BLPaczka\Service\ApiService;
use PrestaShop\Module\BLPaczka\Service\CardService;
use PrestaShop\Module\BLPaczka\Service\OrderService;
use PrestaShop\Module\BLPaczka\Service\RequestService;
use PrestaShopBundle\Entity\Repository\TabRepository;
use Symfony\Component\Form\FormFactory;
use Symfony\Component\Form\FormInterface;
use Twig\Environment;

trait ModuleHelper
{
    public function getOrderListModifier(): AdminOrderListModifier
    {
        /* @var AdminOrderListModifier */
        return $this->get('blpaczka.service.admin_order_list_modifier');
    }

    public function getOrderService(): OrderService
    {
        /* @var OrderService */
        return $this->get('blpaczka.service.order_service');
    }

    public function getCartService(): CardService
    {
        /* @var CardService */
        return $this->get('blpaczka.service.card_service');
    }

    // carrier repository
    public function getCarrierRepository(): CarrierRepository
    {
        /* @var CarrierRepository */
        return $this->get('blpaczka.repository.carrier_repository');
    }

    public function getConfigurationRepository(): ConfigurationRepository
    {
        /* @var ConfigurationRepository */
        return $this->get('blpaczka.configuration.repository.configuration_repository');
    }

    public function getRequestService(): RequestService
    {
        /* @var RequestService */
        return $this->get('blpaczka.service.request_service');
    }

    public function getApiService(): ApiService
    {
        /* @var ApiService */
        return $this->get('blpaczka.service.api_service');
    }

    public function getTwig(): Environment
    {
        /* @var Environment */
        return $this->get('twig');
    }

    public function getRouter()
    {
        return $this->get('router');
    }

    private function createPanelForm(string $title, FormInterface $form, string $extraContent = null): string
    {
        return $this->getTwig()->render('@Modules/blpaczka/views/templates/admin/form_panel.twig', [
            'title' => $title,
            'form' => $form->createView(),
            'extraContent' => $extraContent,
        ]);
    }

    private function getFormFactory(): FormFactory
    {
        return $this->get('form.factory');
    }

    public function getOrderFormDtoFactory(): OrderFormDtoFactory
    {
        return $this->get('blpaczka.factory.order_form_dto_factory');
    }

    public function getTabRepository(): TabRepository
    {
        return $this->get('prestashop.core.admin.tab.repository');
    }

    public function addValidationTranslations()
    {
        $translator = $this->getTranslator();
        $catalogue = $translator->getCatalogue();
        $messages = [
            'A payment method for your package is required.' => 'Metoda płatności dla paczki jest wymagana.',
            'The selected payment method is not valid.' => 'Wybrana metoda płatności nie jest prawidłowa.',
            'A parcel courier is required.' => 'Kurier paczki jest wymagany.',
            'The selected courier is not valid.' => 'Wybrany kurier nie jest prawidłowy.',
            'Package type is required.' => 'Typ paczki jest wymagany.',
            'The selected package type is not valid.' => 'Wybrany typ paczki nie jest prawidłowy.',
            'Package weight is required.' => 'Waga paczki jest wymagana.',
            'Package weight must be a number.' => 'Waga paczki musi być liczbą.',
            'Package weight must be a positive number.' => 'Waga paczki musi być liczbą dodatnią.',
            'Package length is required.' => 'Długość paczki jest wymagana.',
            'Package length must be a number.' => 'Długość paczki musi być liczbą.',
            'Package length must be a positive number.' => 'Długość paczki musi być liczbą dodatnią.',
            'Package width is required.' => 'Szerokość paczki jest wymagana.',
            'Package width must be a number.' => 'Szerokość paczki musi być liczbą.',
            'Package width must be a positive number.' => 'Szerokość paczki musi być liczbą dodatnią.',
            'Package height is required.' => 'Wysokość paczki jest wymagana.',
            'Package height must be a number.' => 'Wysokość paczki musi być liczbą.',
            'Package height must be a positive number.' => 'Wysokość paczki musi być liczbą dodatnią.',
            'Package content description is required.' => 'Opis zawartości paczki jest wymagany.',
            'Content description must be text.' => 'Opis zawartości musi być tekstem.',
            'Package insurance amount must be a number.' => 'Kwota ubezpieczenia paczki musi być liczbą.',
            'COD amount must be a number.' => 'Kwota pobrania musi być liczbą.',
            'Value must be of boolean type (true or false).' => 'Wartość musi być typu logicznego (true lub false).',
            'Pickup date must be a valid date.' => 'Data odbioru musi być poprawną datą.',
            'Pickup ready time must be a valid time.' => 'Czas gotowości odbioru musi być poprawnym czasem.',
            'Pickup close time must be a valid time.' => 'Czas zamknięcia odbioru musi być poprawnym czasem.',
            'Sender\'s name is required.' => 'Nazwa nadawcy jest wymagana.',
            'Sender\'s name cannot be longer than 255 characters.' => 'Nazwa nadawcy nie może być dłuższa niż 255 znaków.',
            'Sender\'s company name cannot be longer than 255 characters.' => 'Nazwa firmy nadawcy nie może być dłuższa niż 255 znaków.',
            'Sender\'s email address is required.' => 'Adres email nadawcy jest wymagany.',
            'Sender\'s email address has an invalid format.' => 'Adres email nadawcy ma nieprawidłowy format.',
            'Sender\'s country code must be text.' => 'Kod kraju nadawcy musi być tekstem.',
            'Sender\'s country code has an invalid format.' => 'Kod kraju nadawcy ma nieprawidłowy format.',
            'Sender\'s street is required.' => 'Ulica nadawcy jest wymagana.',
            'Sender\'s street cannot be longer than 255 characters.' => 'Ulica nadawcy nie może być dłuższa niż 255 znaków.',
            'Sender\'s house number is required.' => 'Numer domu nadawcy jest wymagany.',
            'Sender\'s house number cannot be longer than 10 characters.' => 'Numer domu nadawcy nie może być dłuższy niż 10 znaków.',
            'Sender\'s apartment number cannot be longer than 10 characters.' => 'Numer lokalu nadawcy nie może być dłuższy niż 10 znaków.',
            'Sender\'s postal code is required.' => 'Kod pocztowy nadawcy jest wymagany.',
            'Sender\'s postal code has an invalid format.' => 'Kod pocztowy nadawcy ma nieprawidłowy format.',
            'Sender\'s city is required.' => 'Miasto nadawcy jest wymagane.',
            'Sender\'s city cannot be longer than 255 characters.' => 'Miasto nadawcy nie może być dłuższe niż 255 znaków.',
            'Sender\'s phone number is required.' => 'Telefon nadawcy jest wymagany.',
            'Sender\'s phone number has an invalid format.' => 'Numer telefonu nadawcy ma nieprawidłowy format.',
            'Sender\'s account number is required.' => 'Numer konta nadawcy jest wymagany.',
            'Sender\'s account number has an invalid format.' => 'Numer konta nadawcy ma nieprawidłowy format.',
            'Sender\'s point must be text.' => 'Punkt nadania musi być tekstem.',
            'Recipient\'s name is required.' => 'Nazwa odbiorcy jest wymagana.',
            'Recipient\'s name must be text.' => 'Nazwa odbiorcy musi być tekstem.',
            'Recipient\'s company name must be text.' => 'Nazwa firmy odbiorcy musi być tekstem.',
            'Recipient\'s phone number is required.' => 'Numer telefonu odbiorcy jest wymagany.',
            'Recipient\'s phone number must be text.' => 'Numer telefonu odbiorcy musi być tekstem.',
            'Recipient\'s street is required.' => 'Ulica odbiorcy jest wymagana.',
            'Recipient\'s street must be text.' => 'Ulica odbiorcy musi być tekstem.',
            'Recipient\'s city is required.' => 'Miasto odbiorcy jest wymagane.',
            'Recipient\'s city must be text.' => 'Miasto odbiorcy musi być tekstem.',
            'Recipient\'s house number is required.' => 'Numer domu odbiorcy jest wymagany.',
            'Recipient\'s house number must be text.' => 'Numer domu odbiorcy musi być tekstem.',
            'Recipient\'s apartment number must be text.' => 'Numer lokalu odbiorcy musi być tekstem.',
            'Recipient\'s postal code is required.' => 'Kod pocztowy odbiorcy jest wymagany.',
            'Recipient\'s postal code must be text.' => 'Kod pocztowy odbiorcy musi być tekstem.',
            'Recipient\'s country code has an invalid format.' => 'Kod kraju odbiorcy ma nieprawidłowy format.',
            'Recipient\'s email address is required.' => 'Adres email odbiorcy jest wymagany.',
            'Recipient\'s email address has an invalid format.' => 'Adres email odbiorcy ma nieprawidłowy format.',
            'Recipient\'s notification email has an invalid format.' => 'Email powiadomienia odbiorcy ma nieprawidłowy format.',
            'Recipient\'s notification message must be text.' => 'Wiadomość powiadomienia odbiorcy musi być tekstem.',
            'Delivery point must be text.' => 'Punkt odbioru musi być tekstem.',
            'Pickup point name must be text.' => 'Nazwa punktu odbioru musi być tekstem.',
            'Pickup point city must be text.' => 'Miasto punktu odbioru musi być tekstem.',
            'Pickup point postal code must be text.' => 'Kod pocztowy punktu odbioru musi być tekstem.',
            'Pickup point street must be text.' => 'Ulica punktu odbioru musi być tekstem.',
            'Pickup point house number must be text.' => 'Numer domu punktu odbioru musi być tekstem.',
            'Pickup point apartment number must be text.' => 'Numer lokalu punktu odbioru musi być tekstem.',
            'Pickup point phone number must be text.' => 'Numer telefonu punktu odbioru musi być tekstem.',
            "Sender's name is required." => 'Nazwa nadawcy jest wymagana.',
            "Sender's name cannot exceed 255 characters." => 'Nazwa nadawcy nie może być dłuższa niż 255 znaków.',
            "Sender's company name cannot exceed 255 characters." => 'Nazwa firmy nadawcy nie może być dłuższa niż 255 znaków.',
            "Sender's email address is required." => 'Adres email nadawcy jest wymagany.',
            "Sender's email address has an invalid format." => 'Adres email nadawcy ma nieprawidłowy format.',
            "Sender's street is required." => 'Ulica nadawcy jest wymagana.',
            "Sender's street cannot exceed 255 characters." => 'Ulica nadawcy nie może być dłuższa niż 255 znaków.',
            "Sender's house number is required." => 'Numer domu nadawcy jest wymagany.',
            "Sender's house number cannot exceed 10 characters." => 'Numer domu nadawcy nie może być dłuższy niż 10 znaków.',
            "Sender's apartment number cannot exceed 10 characters." => 'Numer lokalu nadawcy nie może być dłuższy niż 10 znaków.',
            "Sender's postal code is required." => 'Kod pocztowy nadawcy jest wymagany.',
            "Sender's postal code has an invalid format." => 'Kod pocztowy nadawcy ma nieprawidłowy format.',
            "Sender's city is required." => 'Miasto nadawcy jest wymagane.',
            "Sender's city cannot exceed 255 characters." => 'Miasto nadawcy nie może być dłuższe niż 255 znaków.',
            "Sender's country code is required." => 'Kod kraju nadawcy jest wymagany.',
            "Sender's country code has an invalid format." => 'Kod kraju nadawcy ma nieprawidłowy format.',
            "Sender's phone number is required." => 'Numer telefonu nadawcy jest wymagany.',
            "Sender's phone number has an invalid format." => 'Numer telefonu nadawcy ma nieprawidłowy format.',
            "Sender's account number is required." => 'Numer konta nadawcy jest wymagany.',
            "Sender's account number has an invalid format." => 'Numer konta nadawcy ma nieprawidłowy format.',
            'The value must be of boolean type (true or false).' => 'Wartość musi być typu logicznego (true lub false).',
            'Package pickup delay is required.' => 'Opóźnienie odbioru paczki jest wymagane.',
            'Package pickup delay must be a number.' => 'Opóźnienie odbioru paczki musi być liczbą.',
            'Package pickup delay must be a positive number.' => 'Opóźnienie odbioru paczki musi być liczbą dodatnią.',
            'Ready for pickup time must be a valid time.' => 'Czas gotowości odbioru musi być poprawnym czasem.',
            'Package courier is required.' => 'Kurier paczki jest wymagany.',
            'Package payment method is required.' => 'Metoda płatności za paczkę jest wymagana.',
            'Email address is required.' => 'Adres email jest wymagany.',
            'Email address has an invalid format.' => 'Adres email ma nieprawidłowy format.',
            'Authorization key is required.' => 'Klucz autoryzacyjny jest wymagany.',
            'The sandbox value must be of boolean type (true or false).' => 'Wartość sandbox musi być typu logicznego (true lub false).',
            'Please enter a valid phone number.' => 'Wprowadź poprawny numer telefonu.',
            'The value must be a positive number.' => 'Wartość musi być liczbą dodatnią.',
        ];
        $catalogue->add($messages, 'validators');
        $catalogue->add($messages, 'form_error');
    }
}
