<?php
/**
 * 2007-2024 PrestaShop.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright 2007-2024 PrestaShop SA
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 * International Registered Trademark & Property of PrestaShop SA
 */

namespace PrestaShop\Module\BLPaczka\Controller\Admin;

if (!defined('_PS_VERSION_')) {
    exit;
}

use iio\libmergepdf\Merger;
use PrestaShop\Module\BLPaczka\Enum\PrintFormatEnum;
use PrestaShop\Module\BLPaczka\Model\BlpaczkaOrder;
use PrestaShop\Module\BLPaczka\Service\ApiService;
use PrestaShopBundle\Controller\Admin\FrameworkBundleAdminController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\ResponseHeaderBag;

class GetWaybillsBulkActionController extends FrameworkBundleAdminController
{
    /** @var ApiService */
    private $apiService;

    public function __construct(ApiService $apiService)
    {
        parent::__construct();
        $this->apiService = $apiService;
    }

    public function __invoke(Request $request, string $format)
    {
        $orderIds = json_decode($request->getContent(), true);

        if (!is_array($orderIds)) {
            return $this->render('@Modules/blpaczka/views/templates/admin/alert.twig', [
                'type' => 'danger',
                'messages' => [$this->trans('No orders selected.', 'Modules.Blpaczka')],
            ]);
        }

        if (!in_array($format, PrintFormatEnum::getAvailableValues())) {
            return $this->render('@Modules/blpaczka/views/templates/admin/alert.twig', [
                'type' => 'danger',
                'messages' => [$this->trans('Incorrect print format.', 'Modules.Blpaczka')],
            ]);
        }

        if (!extension_loaded('zlib')) {
            return $this->render('@Modules/blpaczka/views/templates/admin/alert.twig', [
                'type' => 'danger',
                'messages' => [$this->trans('To generate a packing list for multiple orders, you need to enable the zlib extension in PHP.', 'Modules.Blpaczka')],
            ]);
        }

        $blpaczkaOrderIds = [];
        foreach ($orderIds as $orderId) {
            $blpaczkaOrder = BlpaczkaOrder::loadByOrderId((int) $orderId);
            if ($blpaczkaOrder && $blpaczkaOrder->blpaczka_order_id) {
                $blpaczkaOrderIds[] = (string) $blpaczkaOrder->blpaczka_order_id;
            }
        }

        if (!is_array($blpaczkaOrderIds)) {
            return $this->render('@Modules/blpaczka/views/templates/admin/alert.twig', [
                'type' => 'danger',
                'messages' => [$this->trans('No orders found BLPaczka.', 'Modules.Blpaczka')],
            ]);
        }

        $waybillResponses = [];
        foreach ($blpaczkaOrderIds as $blpaczkaOrderId) {
            $waybillResponses[] = $this->apiService->getWaybill($blpaczkaOrderId, $format);
        }

        if (!empty($waybillResponses)) {
            $merger = new Merger();
            foreach ($waybillResponses as $waybillResponse) {
                $labels = $waybillResponse['response']['data']['labels'] ?? [];
                $labels = is_array($labels) ? $labels : [];
                foreach ($labels as $file) {
                    if ($file['extension'] !== 'pdf') {
                        continue;
                    }
                    $pdfContent = base64_decode($file['file']);
                    $merger->addRaw($pdfContent);
                }
            }
            $pdfContent = $merger->merge();

            $response = new Response($pdfContent);
            $response->headers->set('Content-Type', 'application/pdf');
            $response->headers->set('Content-Disposition', $response->headers->makeDisposition(
                ResponseHeaderBag::DISPOSITION_ATTACHMENT,
                'blpaczka-waybill-' . implode('-', $orderIds) . '-' . $format . '.pdf'
            ));

            return $response;
        }

        return $this->render('@Modules/blpaczka/views/templates/admin/alert.twig', [
            'type' => 'danger',
            'messages' => [$this->trans('Failed to download packing list.', 'Modules.Blpaczka')],
        ]);
    }
}
