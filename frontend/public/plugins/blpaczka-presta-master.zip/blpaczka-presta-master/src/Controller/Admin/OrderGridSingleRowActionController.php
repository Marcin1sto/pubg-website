<?php
/**
 * 2007-2024 PrestaShop.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright 2007-2024 PrestaShop SA
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 * International Registered Trademark & Property of PrestaShop SA
 */

namespace PrestaShop\Module\BLPaczka\Controller\Admin;

if (!defined('_PS_VERSION_')) {
    exit;
}

use PrestaShop\Module\BLPaczka\Enum\PrintFormatEnum;
use PrestaShop\Module\BLPaczka\Factory\OrderFormDtoFactory;
use PrestaShop\Module\BLPaczka\Model\BlpaczkaOrder;
use PrestaShop\Module\BLPaczka\Service\ApiService;
use PrestaShop\Module\BLPaczka\Service\CarrierService;
use PrestaShop\Module\BLPaczka\Service\OrderService;
use PrestaShopBundle\Controller\Admin\FrameworkBundleAdminController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\ResponseHeaderBag;

class OrderGridSingleRowActionController extends FrameworkBundleAdminController
{
    /** @var CarrierService */
    private $carrierService;

    /** @var ApiService */
    private $apiService;

    /** @var OrderFormDtoFactory */
    private $orderFormDtoFactory;

    /** @var OrderService */
    private $orderService;

    public function __construct(CarrierService $carrierService, ApiService $apiService, OrderFormDtoFactory $orderFormDtoFactory, OrderService $orderService)
    {
        parent::__construct();
        $this->carrierService = $carrierService;
        $this->apiService = $apiService;
        $this->orderFormDtoFactory = $orderFormDtoFactory;
        $this->orderService = $orderService;
    }

    public function __invoke(Request $request, int $orderId)
    {
        /**
         * Case 1: Order is already in BLPaczka system
         */
        $blpaczkaOrder = BlpaczkaOrder::loadByOrderId($orderId);
        if ($blpaczkaOrder && $blpaczkaOrder->blpaczka_order_id) {
            $format = PrintFormatEnum::A4;
            $waybillResponse = $this->apiService->getWaybill($blpaczkaOrder->blpaczka_order_id, $format);
            $labels = $waybillResponse['response']['data']['labels'] ?? [];
            $labels = is_array($labels) ? $labels : [];
            foreach ($labels as $file) {
                if ($file['extension'] !== 'pdf') {
                    continue;
                }
                $pdfContent = base64_decode($file['file']);

                $response = new Response($pdfContent);
                $response->headers->set('Content-Type', 'application/pdf');
                $response->headers->set('Content-Disposition', $response->headers->makeDisposition(
                    ResponseHeaderBag::DISPOSITION_ATTACHMENT,
                    'blpaczka-waybill-' . $orderId . '-' . $format . '.pdf'
                ));

                return $response;
            }
        }

        /**
         * Case 2: Order is not in BLPaczka system, but has carrier mapping
         */
        $mapping = $this->carrierService->getCarrierMappingForOrder($orderId);
        if ($mapping && $mapping->blpaczkaCarrier) {
            $orderFormDto = $this->orderFormDtoFactory->make($orderId);
            $response = $this->apiService->createOrder($orderFormDto);
            if ($response->success) {
                $this->orderService->handleCreateOrderResponse($orderId, $response);
                $this->addFlash('success', $this->trans('An order was created in BLPaczka for order number: %id%', 'Modules.Blpaczka', ['%id%' => $orderId]));
            } else {
                $this->addFlash('error', $this->trans('Failed to create order in BLPaczka for order number: %id%', 'Modules.Blpaczka', ['%id%' => $orderId]));
            }

            return $this->redirectToRoute('admin_orders_index');
        }

        /*
         * Case 3: no mapping
         */
        $this->addFlash('error', $this->trans('Define the courier in the settings', 'Modules.Blpaczka'));

        return $this->redirectToRoute('admin_orders_index');
    }
}
