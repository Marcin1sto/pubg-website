<?php
/**
 * 2007-2024 PrestaShop.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright 2007-2024 PrestaShop SA
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 * International Registered Trademark & Property of PrestaShop SA
 */

namespace PrestaShop\Module\BLPaczka\Controller\Admin;

if (!defined('_PS_VERSION_')) {
    exit;
}

use PrestaShop\Module\BLPaczka\Factory\OrderFormDtoFactory;
use PrestaShop\Module\BLPaczka\Model\BlpaczkaOrder;
use PrestaShop\Module\BLPaczka\Service\ApiService;
use PrestaShop\Module\BLPaczka\Service\CarrierService;
use PrestaShop\Module\BLPaczka\Service\OrderService;
use PrestaShopBundle\Controller\Admin\FrameworkBundleAdminController;
use Symfony\Component\HttpFoundation\Request;

class CreateOrderBulkActionController extends FrameworkBundleAdminController
{
    /** @var OrderFormDtoFactory */
    private $orderFormDtoFactory;
    /** @var ApiService */
    private $apiService;

    /** @var CarrierService */
    private $carrierService;

    /** @var OrderService */
    private $orderService;

    public function __construct(OrderFormDtoFactory $orderFormDtoFactory, ApiService $apiService, CarrierService $carrierService, OrderService $orderService)
    {
        parent::__construct();
        $this->orderFormDtoFactory = $orderFormDtoFactory;
        $this->apiService = $apiService;
        $this->carrierService = $carrierService;
        $this->orderService = $orderService;
    }

    public function __invoke(Request $request)
    {
        $orderIds = $request->request->get('order_orders_bulk');

        if (!is_array($orderIds)) {
            $this->addFlash('warning', $this->trans('No orders selected.', 'Modules.Blpaczka'));

            return $this->redirectToRoute('admin_orders_index');
        }

        $alreadySent = [];
        $creationSuccess = [];
        $creationFailed = [];
        $noCarrierMapping = [];
        foreach ($orderIds as $orderId) {
            /**
             * Case 1: Order is already in BLPaczka system
             */
            $blpaczkaOrder = BlpaczkaOrder::loadByOrderId($orderId);
            if ($blpaczkaOrder && $blpaczkaOrder->blpaczka_order_id) {
                $alreadySent[] = $orderId;
                continue;
            }

            /**
             * Case 2: Order is not in BLPaczka system, but has carrier mapping
             */
            $mapping = $this->carrierService->getCarrierMappingForOrder($orderId);
            if ($mapping && $mapping->blpaczkaCarrier) {
                $orderFormDto = $this->orderFormDtoFactory->make($orderId);
                $response = $this->apiService->createOrder($orderFormDto);
                if ($response->success) {
                    $this->orderService->handleCreateOrderResponse($orderId, $response);
                    $creationSuccess[] = $orderId;
                } else {
                    $creationFailed[] = $orderId;
                }
                continue;
            }

            /*
             * Case 3: no mapping
             */
            $noCarrierMapping[] = $orderId;
        }

        $type = count($creationSuccess) ? !count($creationFailed) ? 'success' : 'warning' : 'error';
        if ($countSuccess = count($creationSuccess)) {
            $message = $this->transPlural(
                $this->trans('1 order created.', 'Modules.Blpaczka'),
                $this->trans('%s orders created.[paucal]', 'Modules.Blpaczka', [$countSuccess]),
                $this->trans('%s orders created.[plural]', 'Modules.Blpaczka', [$countSuccess]),
                $countSuccess
            );
            $this->addFlash($type, $message);
        }

        if ($countFailed = count($creationFailed)) {
            $message = $this->transPlural(
                $this->trans('Failed to create 1 order.', 'Modules.Blpaczka'),
                $this->trans('Failed to create %s orders.[paucal]', 'Modules.Blpaczka', [$countFailed]),
                $this->trans('Failed to create %s orders.[plural]', 'Modules.Blpaczka', [$countFailed]),
                $countFailed
            );
            $this->addFlash($type, $message);
        }

        if ($countAlreadySent = count($alreadySent)) {
            $message = $this->transPlural(
                $this->trans('1 order has already been created.', 'Modules.Blpaczka'),
                $this->trans('%s orders have already been created.[paucal]', 'Modules.Blpaczka', [$countAlreadySent]),
                $this->trans('%s orders have already been created.[plural]', 'Modules.Blpaczka', [$countAlreadySent]),
                $countAlreadySent
            );
            $this->addFlash($type, $message);
        }

        if ($countNoCarrierMapping = count($noCarrierMapping)) {
            $message = $this->transPlural(
                $this->trans('1 order does not have a BLPaczka carrier assigned.', 'Modules.Blpaczka'),
                $this->trans('%s orders do not have a BLPaczka carrier assigned.[paucal]', 'Modules.Blpaczka', [$countNoCarrierMapping]),
                $this->trans('%s orders do not have a BLPaczka carrier assigned.[plural]', 'Modules.Blpaczka', [$countNoCarrierMapping]),
                $countNoCarrierMapping
            );
            $this->addFlash($type, $message);
        }

        return $this->redirectToRoute('admin_orders_index');
    }

    private function getOrderMessage($count, $singular, $paucal, $plural)
    {
        // https://pl.wikipedia.org/wiki/Pluralizm#Pluralizm_w_j%C4%99zyku_polskim
        if ($count == 1) {
            return $singular;
        } elseif ($count % 10 >= 2 && $count % 10 <= 4 && ($count % 100 < 12 || $count % 100 > 14)) {
            return $paucal;
        } else {
            return $plural;
        }
    }

    private function transPlural($singular, $paucal, $plural, $count)
    {
        $message = $this->getOrderMessage($count, $singular, $paucal, $plural);

        // remove [plural] and [paucal] from the message
        $message = preg_replace('/\[(?:plural|paucal)\]/', '', $message);

        return $message;
    }
}
