<?php
/**
 * 2007-2024 PrestaShop.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright 2007-2024 PrestaShop SA
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 * International Registered Trademark & Property of PrestaShop SA
 */

namespace PrestaShop\Module\BLPaczka\Factory;

if (!defined('_PS_VERSION_')) {
    exit;
}

use PrestaShop\Module\BLPaczka\Configuration\Repository\ConfigurationRepository;
use PrestaShop\Module\BLPaczka\Dto\NewBLPaczkaOrderFormDto;
use PrestaShop\Module\BLPaczka\Service\CarrierService;
use PrestaShop\Module\BLPaczka\Service\OrderService;
use VIISON\AddressSplitter\AddressSplitter;

class OrderFormDtoFactory
{
    /** @var CarrierService */
    private $carrierService;

    /** @var ConfigurationRepository */
    private $configurationRepository;

    /** @var OrderService */
    private $orderService;

    /**
     * @param CarrierService $carrierService
     * @param ConfigurationRepository $configurationRepository
     * @param OrderService $orderService
     */
    public function __construct(CarrierService $carrierService, ConfigurationRepository $configurationRepository, OrderService $orderService)
    {
        $this->carrierService = $carrierService;
        $this->configurationRepository = $configurationRepository;
        $this->orderService = $orderService;
    }

    public function make(int $orderId): NewBLPaczkaOrderFormDto
    {
        $order = new \Order($orderId);
        $address = new \Address($order->id_address_delivery);
        $customer = new \Customer($order->id_customer);
        $orderCarrier = new \OrderCarrier($order->getIdOrderCarrier());
        $country = new \Country($address->id_country);

        $mapping = $this->carrierService->getCarrierMappingForOrder($orderId);
        $defaultPackageConfig = $this->configurationRepository->loadDefaultPackageConfiguration();
        $senderConfig = $this->configurationRepository->loadSenderConfiguration();

        $dto = new NewBLPaczkaOrderFormDto();

        $dto->packagePayment = $defaultPackageConfig->packagePayment;
        $dto->courierCode = $mapping->blpaczkaCarrier ? $mapping->blpaczkaCarrier->code : $defaultPackageConfig->packageCourier;
        $dto->parcelType = $defaultPackageConfig->packageType;
        $dto->packageWeight = $orderCarrier ? $orderCarrier->weight : $defaultPackageConfig->packageWeight;
        $dto->packageLength = $defaultPackageConfig->packageLength;
        $dto->packageWidth = $defaultPackageConfig->packageWidth;
        $dto->packageHeight = $defaultPackageConfig->packageHeight;
        $dto->packageContent = $defaultPackageConfig->packageContent;
        $dto->cover = null;
        $dto->uptake = null;
        $dto->packageSortable = $defaultPackageConfig->packageSortable;
        $dto->noPickup = $defaultPackageConfig->packageNoPickup;
        $dto->pickupDate = $defaultPackageConfig->pickupDateDelay ? new \DateTime('+' . $defaultPackageConfig->pickupDateDelay . ' days') : null;
        $dto->pickupReadyTime = $defaultPackageConfig->pickupReadyTime;
        $dto->pickupCloseTime = $defaultPackageConfig->pickupCloseTime;

        // sender
        $dto->senderName = $senderConfig->senderName;
        $dto->senderCompany = $senderConfig->senderCompany;
        $dto->senderEmail = $senderConfig->senderEmail;
        $dto->senderStreet = $senderConfig->senderStreet;
        $dto->senderHouseNo = $senderConfig->senderHouseNo;
        $dto->senderLocumNo = $senderConfig->senderLocumNo;
        $dto->senderPostal = $senderConfig->senderPostal;
        $dto->senderCity = $senderConfig->senderCity;
        $dto->senderPhone = $senderConfig->senderPhone;
        $dto->senderAccount = $senderConfig->senderAccount;
        $dto->senderCountryCode = $senderConfig->senderCountryCode;

        // taker
        $dto->takerName = $customer->firstname . ' ' . $customer->lastname;
        $dto->takerCompany = $customer->company;
        $dto->takerEmail = $customer->email;
        $dto->takerPhone = $address->phone ?? $address->phone_mobile ?? null;
        $dto->takerPoint = $mapping->blpaczkaCarrier ? $this->orderService->getPudoCode($orderId, $mapping->blpaczkaCarrier->apiType) : null;
        try {
            $takerAddress = AddressSplitter::splitAddress($address->address1 . ' ' . $address->address2);
        } catch (\Exception $e) {
            $takerAddress = [
                'streetName' => $address->address1,
                'houseNumber' => $address->address2,
            ];
        }
        $dto->takerStreet = $takerAddress['streetName'] ?? null;
        $dto->takerHouseNo = $takerAddress['houseNumber'] ?? null;
        $dto->takerLocumNo = $takerAddress['additionToAddress2'] ?? null;
        // if house number have / then split it
        if (strpos($dto->takerHouseNo, '/') !== false) {
            $houseNo = explode('/', $dto->takerHouseNo);
            $dto->takerHouseNo = $houseNo[0];
            $dto->takerLocumNo = $houseNo[1];
        }
        $dto->takerCity = $address->city;
        $dto->takerPostal = $address->postcode;
        $dto->takerCountryCode = $country->iso_code;

        return $dto;
    }
}
