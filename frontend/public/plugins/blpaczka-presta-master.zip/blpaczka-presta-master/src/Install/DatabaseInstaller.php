<?php
/**
 * 2007-2024 PrestaShop.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright 2007-2024 PrestaShop SA
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 * International Registered Trademark & Property of PrestaShop SA
 */

namespace PrestaShop\Module\BLPaczka\Install;

if (!defined('_PS_VERSION_')) {
    exit;
}

class DatabaseInstaller
{
    /** @var \Db */
    private $db;

    public function __construct()
    {
        $this->db = \Db::getInstance();
    }

    public function install(): bool
    {
        return $this->db->execute('
            CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'blpaczka_order` (
                `id_blpaczka_order` INT(11) NOT NULL AUTO_INCREMENT,
                `order_id` INT(11) NOT NULL,
                `pudo_code` VARCHAR(255) NOT NULL,
                `api_type` VARCHAR(255) NOT NULL,
                `waybill_link` VARCHAR(1023) DEFAULT NULL,
                `id_prefix` VARCHAR(50) DEFAULT NULL,
                `price` DECIMAL(10, 2) DEFAULT NULL,
                `price_netto` DECIMAL(10, 2) DEFAULT NULL,
                `payment_url` VARCHAR(1023) DEFAULT NULL,
                `waybill_no` VARCHAR(255) DEFAULT NULL,
                `blpaczka_order_id` VARCHAR(50) DEFAULT NULL,
                `blpaczka_order_name` VARCHAR(255) DEFAULT NULL,
                `raw_request` TEXT NULL DEFAULT NULL,
                `raw_response` TEXT NULL DEFAULT NULL,
                PRIMARY KEY (`id_blpaczka_order`),
                INDEX idx_order (order_id),
                INDEX idx_order_pudo (order_id, pudo_code)
            );
        ')
        && $this->db->execute('
            CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'blpaczka_card` (
                `id_blpaczka_card` INT(11) NOT NULL AUTO_INCREMENT,
                `card_id` INT(11) NOT NULL,
                `pudo_code` VARCHAR(255) NOT NULL,
                `api_type` VARCHAR(255) NOT NULL,
                PRIMARY KEY (`id_blpaczka_card`),
                INDEX idx_card (card_id),
                INDEX idx_card_pudo (card_id, pudo_code)
            )
        ')
        && $this->db->execute('
            CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'blpaczka_tracking_status` (
                `id_blpaczka_tracking_status` INT(11) NOT NULL AUTO_INCREMENT,
                `blpaczka_order_id` INT(11) NOT NULL,
                `status` VARCHAR(50) NOT NULL,
                `status_desc` VARCHAR(255) NOT NULL,
                `bl_status_mapped` VARCHAR(50) NOT NULL,
                `terminal` VARCHAR(255) DEFAULT NULL,
                `error_desc` VARCHAR(1023) DEFAULT NULL,
                `delivered` TINYINT(1) NOT NULL,
                `received_by` VARCHAR(255) DEFAULT NULL,
                `event_time` DATETIME NOT NULL,
                PRIMARY KEY (`id_blpaczka_tracking_status`),
                UNIQUE INDEX idx_unique_status (`status`, `bl_status_mapped`, `event_time`),
                INDEX idx_search_params (`status`, `bl_status_mapped`, `event_time`, `blpaczka_order_id`)
            );
        ');
    }

    public function uninstall(): bool
    {
        return $this->db->execute('DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'blpaczka_order`')
        && $this->db->execute('DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'blpaczka_card`')
        && $this->db->execute('DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'blpaczka_tracking_status`');
    }
}
