<?php
/**
 * 2007-2024 PrestaShop.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright 2007-2024 PrestaShop SA
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 * International Registered Trademark & Property of PrestaShop SA
 */

namespace PrestaShop\Module\BLPaczka\Repository;

if (!defined('_PS_VERSION_')) {
    exit;
}

use PrestaShop\Module\BLPaczka\Dto\BLPaczkaCurrierDto;
use PrestaShop\Module\BLPaczka\Dto\PrestashopCurrierDto;
use PrestaShop\Module\BLPaczka\Enum\CourierCodeEnum;
use PrestaShop\Module\BLPaczka\Enum\CourierMapEnum;
use PrestaShop\Module\BLPaczka\Traits\Trans;

class CarrierRepository
{
    use Trans;

    /**
     * @return BLPaczkaCurrierDto[]
     */
    public function getAllBLPaczkaCarriers(): array
    {
        return [
            new BLPaczkaCurrierDto(CourierCodeEnum::ALLEGRO_SMART_DPD, $this->trans('Allegro Smart DPD'), CourierMapEnum::OPTIONAL),
            new BLPaczkaCurrierDto(CourierCodeEnum::ALLEGRO_SMART_ECOMMERCE, $this->trans('Allegro Smart eCommerce'), CourierMapEnum::NO_MAP),
            new BLPaczkaCurrierDto(CourierCodeEnum::ALLEGRO_SMART_POCZTA, $this->trans('Allegro Smart Poczta'), CourierMapEnum::OPTIONAL),
            new BLPaczkaCurrierDto(CourierCodeEnum::AMBRO_EXPRESS, $this->trans('Ambro Express'), CourierMapEnum::NO_MAP),
            new BLPaczkaCurrierDto(CourierCodeEnum::BLP_CROSS_BORDER, $this->trans('BLP Cross Border'), CourierMapEnum::NO_MAP),
            new BLPaczkaCurrierDto(CourierCodeEnum::BLP_CROSS_BORDER_ECO, $this->trans('BLP Cross Border Eco'), CourierMapEnum::NO_MAP),
            new BLPaczkaCurrierDto(CourierCodeEnum::DHL, $this->trans('DHL'), CourierMapEnum::OPTIONAL),
            new BLPaczkaCurrierDto(CourierCodeEnum::DPD, $this->trans('DPD'), CourierMapEnum::OPTIONAL),
            new BLPaczkaCurrierDto(CourierCodeEnum::EURO_HERMES, $this->trans('Euro Hermes'), CourierMapEnum::NO_MAP),
            new BLPaczkaCurrierDto(CourierCodeEnum::FEDEX, $this->trans('FedEx'), CourierMapEnum::NO_MAP),
            new BLPaczkaCurrierDto(CourierCodeEnum::FEDEX_REST, $this->trans('FedEx REST'), CourierMapEnum::NO_MAP),
            new BLPaczkaCurrierDto(CourierCodeEnum::GLS, $this->trans('GLS'), CourierMapEnum::NO_MAP),
            new BLPaczkaCurrierDto(CourierCodeEnum::GEODIS, $this->trans('GEODIS'), CourierMapEnum::NO_MAP),
            new BLPaczkaCurrierDto(CourierCodeEnum::GEIS, $this->trans('Geis'), CourierMapEnum::NO_MAP),
            new BLPaczkaCurrierDto(CourierCodeEnum::HELLMAN, $this->trans('Hellmann'), CourierMapEnum::NO_MAP),
            new BLPaczkaCurrierDto(CourierCodeEnum::INPOST, $this->trans('InPost'), CourierMapEnum::NO_MAP),
            new BLPaczkaCurrierDto(CourierCodeEnum::INPOST_INTERNATIONAL, $this->trans('InPost International'), CourierMapEnum::REQUIRED),
            new BLPaczkaCurrierDto(CourierCodeEnum::OLZA_LOGISTIC, $this->trans('Olza Logistic'), CourierMapEnum::NO_MAP),
            new BLPaczkaCurrierDto(CourierCodeEnum::ORLEN, $this->trans('ORLEN Paczka'), CourierMapEnum::REQUIRED),
            new BLPaczkaCurrierDto(CourierCodeEnum::PACZKOMATY, $this->trans('Paczkomaty'), CourierMapEnum::REQUIRED),
            new BLPaczkaCurrierDto(CourierCodeEnum::PACZKOMATY_ALLEGRO_SMART, $this->trans('Paczkomaty Allegro Smart'), CourierMapEnum::REQUIRED),
            new BLPaczkaCurrierDto(CourierCodeEnum::PACZKOMATY_ECO, $this->trans('Paczkomaty Eco'), CourierMapEnum::REQUIRED),
            new BLPaczkaCurrierDto(CourierCodeEnum::PACZKOMATY_TO_DOOR, $this->trans('Paczkomaty To Door'), CourierMapEnum::NO_MAP),
            new BLPaczkaCurrierDto(CourierCodeEnum::POCZTA, $this->trans('Poczta Polska'), CourierMapEnum::OPTIONAL),
            new BLPaczkaCurrierDto(CourierCodeEnum::POCZTA_ECOMMERCE_ENVELOPE, $this->trans('Poczta Polska eCommerce Koperta'), CourierMapEnum::NO_MAP),
            new BLPaczkaCurrierDto(CourierCodeEnum::SPRING, $this->trans('Spring'), CourierMapEnum::NO_MAP),
            new BLPaczkaCurrierDto(CourierCodeEnum::UPS, $this->trans('UPS'), CourierMapEnum::NO_MAP),
        ];
    }

    /**
     * @return PrestashopCurrierDto[]
     */
    public function getAllPrestashopCarriers(): array
    {
        return PrestashopCurrierDto::fromRows(\Carrier::getCarriers(
            \Context::getContext()->language->id,
            true,
            false,
            false,
            null,
            \Carrier::ALL_CARRIERS
        ));
    }

    public function getPrestashopCarrierByOrderId(int $orderId): ?PrestashopCurrierDto
    {
        $order = new \Order($orderId);
        $orderCarrier = new \OrderCarrier($order->getIdOrderCarrier());
        $carrier = new \Carrier($orderCarrier->id_carrier);

        foreach ($this->getAllPrestashopCarriers() as $carrierItem) {
            if ($carrierItem->referenceId == $carrier->id_reference) {
                return $carrierItem;
            }
        }

        return null;
    }
}
