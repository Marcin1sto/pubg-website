<?php
/**
 * 2007-2024 PrestaShop.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright 2007-2024 PrestaShop SA
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 * International Registered Trademark & Property of PrestaShop SA
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

if (file_exists($autoloadPath = dirname(__FILE__) . '/vendor/autoload.php')) {
    require_once $autoloadPath;
}

use PrestaShop\Module\BLPaczka\Configuration\Configs;
use PrestaShop\Module\BLPaczka\Configuration\Form\AuthConfigurationType;
use PrestaShop\Module\BLPaczka\Configuration\Form\CarrierMappingConfigurationType;
use PrestaShop\Module\BLPaczka\Configuration\Form\DefaultPackageConfigurationType;
use PrestaShop\Module\BLPaczka\Configuration\Form\SenderConfigurationType;
use PrestaShop\Module\BLPaczka\Dto\API\Response\GetValuationResponseResultItem;
use PrestaShop\Module\BLPaczka\Enum\PrintFormatEnum;
use PrestaShop\Module\BLPaczka\Form\CancelOrderStep1Type;
use PrestaShop\Module\BLPaczka\Form\CancelOrderStep2Type;
use PrestaShop\Module\BLPaczka\Form\NewBLPaczkaOrderType;
use PrestaShop\Module\BLPaczka\Install\DatabaseInstaller;
use PrestaShop\Module\BLPaczka\Model\BlpaczkaOrder;
use PrestaShop\Module\BLPaczka\Model\BlpaczkaTrackingStatus;
use PrestaShop\Module\BLPaczka\Traits\ModuleHelper;
use Symfony\Component\Form\FormError;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;

class BLPaczka extends CarrierModule
{
    use ModuleHelper;

    /**
     * @throws Exception
     */
    public function __construct()
    {
        $this->name = 'blpaczka';
        $this->tab = 'shipping_logistics';
        $this->version = '1.0.0';
        $this->author = 'BLPaczka';
        $this->need_instance = 0;
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->trans('BLPaczka');
        $this->description = $this->trans('BLPaczka integration module for PrestaShop');
        $this->confirmUninstall = $this->trans('Are you sure you want to uninstall?');

        if (!Configuration::get(Configs::AUTH_EMAIL) || !Configuration::get(Configs::AUTH_KEY)) {
            $this->warning = $this->trans('Authorization settings are missing.');
        }

        $this->ps_versions_compliancy = ['min' => '1.7.8.0', 'max' => '8.2.999.999'];
    }

    public function isUsingNewTranslationSystem(): bool
    {
        return true;
    }

    public function install(): bool
    {
        return parent::install()
            && (new DatabaseInstaller())->install()
            && $this->registerHook('actionCartSave')
            && $this->registerHook('actionCarrierProcess')
            && $this->registerHook('actionValidateOrder') // Hook do walidacji zamówienia
            && $this->registerHook('displayCarrierList') // Hook do walidacji zamówienia
            && $this->registerHook('displayAfterCarrier') // Hook do walidacji zamówienia
            && $this->registerHook('actionOrderGridDefinitionModifier') // Hook do modyfikacji kolumn zamówień w Adminie
            && $this->registerHook('actionOrderGridDataModifier') // Hook do modyfikacji wartości kolumn zamówień w Adminie
            && $this->registerHook('displayPDFDeliverySlip')
            && $this->registerHook('actionValidateOrderBefore')
            && $this->registerHook('actionDispatcher')
            && $this->registerHook('displayOrderDetail')
            && $this->registerHook('displayAdminOrder')
            && $this->registerHook('displayAdminGridTableAfter')
            && $this->registerHook('actionValidateCustomerAddressForm')
            && $this->addAdminTab()
        ;
    }

    public function uninstall()
    {
        return
            $this->removeAdminTab()
            && (new DatabaseInstaller())->uninstall()
            && $this->unregisterHook('actionCartSave')
            && $this->unregisterHook('actionCarrierProcess')
            && $this->unregisterHook('actionValidateOrder')
            && $this->unregisterHook('displayCarrierList')
            && $this->unregisterHook('displayAfterCarrier')
            && $this->unregisterHook('actionOrderGridDefinitionModifier')
            && $this->unregisterHook('actionOrderGridDataModifier')
            && $this->unregisterHook('displayPDFDeliverySlip')
            && $this->unregisterHook('actionValidateOrderBefore')
            && $this->unregisterHook('actionDispatcher')
            && $this->unregisterHook('displayOrderDetail')
            && $this->unregisterHook('displayAdminOrder')
            && $this->unregisterHook('displayAdminGridTableAfter')
            && $this->unregisterHook('actionValidateCustomerAddressForm')
            // Remove all configuration keys
            && min(array_map(
                function ($configKey) {
                    return Configuration::deleteByName($configKey);
                },
                Configs::getAllConfigurationKeys()
            ))
            && parent::uninstall()
        ;
    }

    public function hookActionValidateCustomerAddressForm($params)
    {
        if ($phoneField = $params['form']->getField('phone')) {
            $phoneField->setRequired(true);
        }
    }

    private function addAdminTab()
    {
        $tab = new Tab();
        $tab->id_parent = $this->getTabRepository()->findOneIdByClassName('AdminParentShipping');
        $tab->active = 1;
        $tab->module = 'blpaczka';
        foreach (Language::getLanguages(true) as $lang) {
            $tab->name[$lang['id_lang']] = 'BLPaczka';
        }
        $tab->class_name = 'AdminConfigurationBlpaczka';
        $tab->route_name = 'blpaczka_module_configuration_proxy_route';

        return $tab->add();
    }

    private function removeAdminTab()
    {
        if ($tabId = $this->getTabRepository()->findOneIdByClassName('AdminConfigurationBlpaczka')) {
            $tab = new Tab($tabId);

            return $tab->delete();
        }

        return true;
    }

    public function getContent(): string
    {
        $this->addValidationTranslations();

        $content = '';
        $formFactory = $this->getFormFactory();
        $carrierRepo = $this->getCarrierRepository();
        $configRepo = $this->getConfigurationRepository();
        $requestService = $this->getRequestService();
        $twig = $this->getTwig();
        $router = $this->getRouter();
        $successMessage = $this->trans('Settings have been updated.');
        $errorMessage = $this->trans('An error occurred while saving settings.');

        // Autoryzacja
        $form = $formFactory->create(AuthConfigurationType::class, $configRepo->loadAuthConfiguration());
        $form->handleRequest($requestService->getRequest());
        if ($form->isSubmitted() && $form->isValid()) {
            $configRepo->saveAuthConfiguration($form->getData());
            $this->context->controller->confirmations[] = $successMessage;
        } elseif ($form->isSubmitted()) {
            $this->context->controller->errors[] = $errorMessage;
        }
        $extraContent = $twig->render('@Modules/blpaczka/views/templates/admin/configuration/auth_extra_content.twig', [
            'url' => $router->generate('blpaczka_check_api_connection_route', [], UrlGeneratorInterface::ABSOLUTE_URL),
        ]);

        $content .= $this->createPanelForm($this->trans('Autoryzacja'), $form, $extraContent);

        // Domyślna paczka
        $form = $formFactory->create(DefaultPackageConfigurationType::class, $configRepo->loadDefaultPackageConfiguration(), [
            'blpaczkaCarriers' => $carrierRepo->getAllBLPaczkaCarriers(),
        ]);
        $form->handleRequest($requestService->getRequest());
        if ($form->isSubmitted() && $form->isValid()) {
            $configRepo->saveDefaultPackageConfiguration($form->getData());
            $this->context->controller->confirmations[] = $successMessage;
        } elseif ($form->isSubmitted()) {
            $this->context->controller->errors[] = $errorMessage;
        }
        $content .= $this->createPanelForm($this->trans('Default package'), $form);

        // Dane nadawcy
        $form = $formFactory->create(SenderConfigurationType::class, $configRepo->loadSenderConfiguration());
        $form->handleRequest($requestService->getRequest());
        if ($form->isSubmitted() && $form->isValid()) {
            $configRepo->saveSenderConfiguration($form->getData());
            $this->context->controller->confirmations[] = $successMessage;
        } elseif ($form->isSubmitted()) {
            $this->context->controller->errors[] = $errorMessage;
        }
        $content .= $this->createPanelForm($this->trans('Sender details'), $form);

        // Mapowanie przewoźników
        $form = $formFactory->create(CarrierMappingConfigurationType::class, $configRepo->loadCarrierMappingConfiguration(), [
            'blpaczkaCarriers' => $carrierRepo->getAllBLPaczkaCarriers(),
        ]);
        $form->handleRequest($requestService->getRequest());
        if ($form->isSubmitted() && $form->isValid()) {
            $configRepo->saveCarrierMappingConfiguration($form->getData());
            $this->context->controller->confirmations[] = $successMessage;
        } elseif ($form->isSubmitted()) {
            $this->context->controller->errors[] = $errorMessage;
        }
        $extraContent = $twig->render('@Modules/blpaczka/views/templates/admin/configuration/carrier_mapping_extra_content.twig', [
            'carrierMapping' => $configRepo->loadCarrierMappingConfiguration()->mapping,
            'blpaczkaCarriers' => $carrierRepo->getAllBLPaczkaCarriers(),
        ]);

        $content .= $this->createPanelForm($this->trans('Mapping'), $form, $extraContent);

        return $content;
    }

    public function getOrderShippingCost($params, $shipping_cost)
    {
        return false;
    }

    public function getOrderShippingCostExternal($params)
    {
        return false;
    }

    /** @noinspection PhpUnused */
    public function hookActionOrderGridDefinitionModifier(array $params)
    {
        $this->getOrderListModifier()->modifyColumns($params);
        $this->getOrderListModifier()->modifyBulkActions($params);
    }

    /** @noinspection PhpUnused */
    public function hookActionOrderGridDataModifier(array $params)
    {
        $this->getOrderListModifier()->modifyData($params);
    }

    /** @noinspection PhpUnused */
    public function hookDisplayAdminGridTableAfter($props)
    {
        if ($props['legacy_controller'] === 'AdminOrders') {
            return $this->getTwig()->render('@Modules/blpaczka/views/templates/admin/orders_page/loader.twig', [
                'getWaybillsA4Url' => $this->getRouter()->generate('blpaczka_get_waybills_bulk_action_route', ['format' => PrintFormatEnum::A4]),
                'getWaybillsA6Url' => $this->getRouter()->generate('blpaczka_get_waybills_bulk_action_route', ['format' => PrintFormatEnum::LBL]),
            ]);
        }
    }

    public function hookDisplayCarrierList()
    {
        $this->context->smarty->assign(['blpaczka' => [
            'mapEndpoint' => $this->getApiService()->getMapEndpoint(),
            'carriersMapping' => $this->getConfigurationRepository()->loadCarrierMappingConfiguration()->mapping,
        ]]);

        return $this->display(__FILE__, 'displayCarrierList_17.tpl');
    }

    /**
     * hookDisplayCarrierList alias for PS1.7 version
     *
     * @noinspection PhpUnused
     */
    public function hookDisplayAfterCarrier()
    {
        return $this->hookDisplayCarrierList();
    }

    /** @noinspection PhpUnused */
    public function hookActionCartSave($params)
    {
        if (($pickupPointCode = Tools::getValue('blpaczka_pudo_code'))
            && ($pickupApiType = Tools::getValue('blpaczka_pudo_api_type'))
        ) {
            $this->getCartService()->saveCardData($params['cart']->id, $pickupPointCode, $pickupApiType);
        }
    }

    /** @noinspection PhpUnused */
    public function hookActionValidateOrderBefore()
    {
        if ($carrierId = $this->context->cart->id_carrier) {
            $mappingArray = $this->getConfigurationRepository()->loadCarrierMappingConfiguration()->mapping;
            foreach ($mappingArray as $carrier) {
                if ($carrier->prestashopCarrier->id == $carrierId) {
                    if ($carrier->blpaczkaCarrier && $carrier->showMap) {
                        if (!$this->getCartService()->getPudoCode($this->context->cart->id, $carrier->blpaczkaCarrier->apiType)) {
                            $this->context->cookie->__set('blpaczka_validation_error', $this->trans('No pick-up point selected'));
                            Tools::redirect('index.php?controller=order');
                        }
                    }
                }
            }
        }
    }

    /** @noinspection PhpUnused */
    public function hookActionCarrierProcess($params)
    {
        if (($pickupPointCode = Tools::getValue('blpaczka_pudo_code'))
            && ($pickupApiType = Tools::getValue('blpaczka_pudo_api_type'))
        ) {
            $this->getCartService()->saveCardData($params['cart']->id, $pickupPointCode, $pickupApiType);
        }
    }

    /** @noinspection PhpUnused */
    public function hookActionValidateOrder($params)
    {
        $this->getOrderService()->saveOrderData($params['cart']->id, $params['order']->id);
    }

    /** @noinspection PhpUnused */
    public function hookDisplayPDFDeliverySlip(array $params)
    {
        $getSafeReferer = function () {
            $referer = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : null;

            if (!$referer || !filter_var($referer, FILTER_VALIDATE_URL)) {
                return false;
            }

            $parsedUrl = parse_url($referer);
            $trustedDomain = parse_url(_PS_BASE_URL_, PHP_URL_HOST);
            if ($parsedUrl['host'] !== $trustedDomain) {
                return false;
            }

            $adminFolder = basename(_PS_ADMIN_DIR_);
            if (str_starts_with($referer, "http://$trustedDomain/$adminFolder/index.php/sell/orders/") ||
                str_starts_with($referer, "https://$trustedDomain/$adminFolder/index.php/sell/orders/")
            ) {
                return $referer;
            }
            return false;
        };
        $is404 = function ($link) {
            $ch = curl_init($link);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_NOBODY, true);

            curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            return $httpCode === 404;
        };
        $orderId = $params['object']->id_order;
        if ($blpaczkaOrder = BlpaczkaOrder::loadByOrderId($orderId)) {
            $link = $blpaczkaOrder->waybill_link;
            if ($link && $is404($link) && $getSafeReferer()) {
                $this->get('session')->getFlashBag()->add('error', $this->trans('Failed to download packing list.'));
                Tools::redirect($getSafeReferer());
                exit;
            }
            if ($link && !$is404($link)) {
                $pdf = Tools::file_get_contents($link);
                if ($pdf) {
                    $response = new Response();
                    $response->headers->set('Content-Type', 'application/pdf');
                    $response->headers->set('Content-Disposition', 'attachment; filename="blpaczka_' . $orderId . '.pdf"');
                    $response->setContent($pdf);
                    $response->send();
                    exit;
                }
            }
        }
    }

    /** @noinspection PhpUnused */
    public function hookDisplayOrderDetail($props)
    {
        /* @var Order $order */
        $order = $props['order'];

        $blpaczkaOrder = BlpaczkaOrder::loadByOrderId($order->id);
        if ($blpaczkaOrder && $blpaczkaOrder->blpaczka_order_id) {
            $rsp = $this->getApiService()->getWaybillTracking($blpaczkaOrder->blpaczka_order_id);
            foreach ($rsp->trackingStatuses as $trackingStatus) {
                BlpaczkaTrackingStatus::createIfNotExist($trackingStatus);
            }

            $trackingStatuses = BlpaczkaTrackingStatus::loadAllByBlpaczkaOrderId($blpaczkaOrder->blpaczka_order_id);
            if (!empty($trackingStatuses)) {
                $this->context->smarty->assign(['trackingStatuses' => $trackingStatuses]);

                return $this->display(__FILE__, 'displayOrderDetail.tpl');
            }
        }
    }

    /** @noinspection PhpUnused */
    public function hookActionDispatcher($props)
    {
        if ($error = $this->context->cookie->__get('blpaczka_validation_error')) {
            $this->context->cookie->__unset('blpaczka_validation_error');
            $this->context->controller->errors[] = $error;
        }
    }

    /**
     * Selected courier: chosen from the list of couriers from the valuation
     */
    private function getChosenValuationItem(): ?GetValuationResponseResultItem
    {
        if ($data = json_decode(Tools::getValue('blpaczka_selected_courier'), false)) {
            return GetValuationResponseResultItem::fromStdClass($data);
        }

        return null;
    }

    /** @noinspection PhpUnused */
    public function hookDisplayAdminOrder($props)
    {
        $this->addValidationTranslations();

        $orderId = (int) $props['id_order'];
        $dto = $this->getOrderFormDtoFactory()->make($orderId);
        $chosenValuationItem = $this->getChosenValuationItem();
        $valuation = null;
        $response = null;

        $blpaczkaOrder = BlpaczkaOrder::loadByOrderId($orderId);
        if ($blpaczkaOrder && $blpaczkaOrder->id_prefix) {
            $request = $this->getRequestService()->getRequest();

            // Cancel order forms
            $cancelOrderStep1 = $this->getFormFactory()->create(CancelOrderStep1Type::class);
            $cancelOrderStep2 = $this->getFormFactory()->create(CancelOrderStep2Type::class);

            // Default form is the first step
            $cancelOrderForm = $cancelOrderStep1;

            // Check if the first step was submitted
            $cancelOrderStep1->handleRequest($request);
            if ($cancelOrderStep1->isSubmitted() && $cancelOrderStep1->isValid()) {
                // If the first step was submitted, show the second step
                $cancelOrderForm = $cancelOrderStep2;
            }

            // Check if the second step was submitted
            $cancelOrderStep2->handleRequest($request);
            if ($cancelOrderStep2->isSubmitted() && $cancelOrderStep2->isValid() && $cancelOrderStep2->get('confirm')->isClicked()) {
                // If the second step was submitted and the confirm button was clicked, cancel the order
                $response = $this->getApiService()->cancelOrder($blpaczkaOrder->blpaczka_order_id);
                if ($response->success) {
                    $success = $this->getOrderService()->handleCancelOrderResponse($orderId, $response);
                    if ($success) {
                        $this->get('session')->getFlashBag()->add('success', $this->trans('Order canceled.'));
                    } else {
                        $this->get('session')->getFlashBag()->add('error', $this->trans('An error occurred while canceling your order.'));
                    }
                } else {
                    $this->get('session')->getFlashBag()->add('error', $response->message ?? $this->trans('An error occurred while canceling your order.'));
                }
                Tools::redirectAdmin($this->context->link->getAdminLink('AdminOrders', true, ['vieworder' => '', 'id_order' => $orderId]));
            }

            $cartOrderStatus = $this->getApiService()->getCartOrderStatus($blpaczkaOrder->id_prefix);
            $waybillTracking = $this->getApiService()->getWaybillTracking($blpaczkaOrder->blpaczka_order_id);

            return $this->getTwig()->render('@Modules/blpaczka/views/templates/admin/order_details_page/order_details_card.twig', [
                'form' => $cancelOrderForm->createView(),
                'blpaczkaOrder' => $blpaczkaOrder,
                'cartOrderStatus' => $cartOrderStatus,
                'trackingStatuses' => $waybillTracking ? $waybillTracking->trackingStatuses : null,
                'orderId' => $orderId,
            ]);
        }

        $form = $this->getFormFactory()->create(NewBLPaczkaOrderType::class, $dto, [
            'blpaczkaCarriers' => $this->getCarrierRepository()->getAllBLPaczkaCarriers(),
            'preSubmitDataModifier' => function ($data) use ($chosenValuationItem, $orderId) {
                // If the courier was chosen from the valuation, override some data
                if ($chosenValuationItem) {
                    $courierCode = $chosenValuationItem->courier->courierCode;
                    $data['courierCode'] = $courierCode;
                    $data['takerPoint'] = $this->getOrderService()->getPudoCode($orderId, $courierCode);
                }

                return $data;
            },
        ]);

        $form->handleRequest($this->getRequestService()->getRequest());
        if ($form->isSubmitted() && $form->isValid()) {
            // Get valuation
            if ($form->get('pricing')->isClicked()) {
                $response = $valuation = $this->getApiService()->getValuation($form->getData());
            }
            // Create order
            if ($form->get('order')->isClicked()) {
                $response = $this->getApiService()->createOrder($form->getData());
                if ($response->success) {
                    $this->getOrderService()->handleCreateOrderResponse($orderId, $response);
                    $this->get('session')->getFlashBag()->add('success', $this->trans('The shipment has been sent. You can now download the waybill.'));
                    // Reload the page to show the waybill
                    Tools::redirectAdmin($this->context->link->getAdminLink('AdminOrders', true, ['vieworder' => '', 'id_order' => $orderId]));
                }
            }
            // Add errors to the form
            if ($response) {
                foreach ($response->errors as $error) {
                    $form->addError(new FormError($error));
                }
            }
        }

        return $this->getTwig()->render('@Modules/blpaczka/views/templates/admin/order_details_page/order_form_card.twig', [
            'form' => $form->createView(),
            'valuation' => $valuation,
            'blpaczkaCarriers' => $this->getCarrierRepository()->getAllBLPaczkaCarriers(),
            'mapEndpoint' => $this->getApiService()->getMapEndpoint(),
        ]);
    }

    protected function trans($id, array $parameters = [], $domain = null, $locale = null)
    {
        return parent::trans($id, $parameters, $domain ?? 'Modules.Blpaczka', $locale);
    }
}
