# Instalacja modułu BLPaczka dla PrestaShop

Ten dokument opisuje kroki instalacji modułu BLPaczka w sklepie opartym na PrestaShop (>=1.7.8)

## Wymagania wstępne

- Sklep internetowy oparty na PrestaShop w wersji 1.7.8 lub nowszej
- Dostęp do panelu administracyjnego PrestaShop
- Plik modułu BLPaczka w formacie `.zip`

## Kroki instalacji

### 1. Zaloguj się do panelu administracyjnego

Zaloguj się do panelu administracyjnego swojego sklepu PrestaShop, używając swoich danych logowania.

### 2. Przejdź do sekcji modułów

W menu po lewej stronie wybierz opcję **Moduły** i kliknij **Menedżer modułów**.

### 3. Dodaj nowy moduł

Kliknij przycisk **Załaduj moduł** znajdujący się w prawym górnym rogu strony.

### 4. Prześlij plik modułu

W oknie dialogowym kliknij **Wybierz plik**, a następnie wybierz plik `.zip` modułu BLPaczka ze swojego komputera. Po wybraniu pliku kliknij **Prześlij**.

### 5. Zainstaluj moduł

Po pomyślnym przesłaniu modułu znajdź go na liście dostępnych modułów i kliknij przycisk **Zainstaluj**.

### 6. Potwierdź instalację

Potwierdź instalację modułu, jeśli pojawi się takie zapytanie.

### 7. Skonfiguruj moduł

Po zainstalowaniu kliknij **Konfiguruj**, aby ustawić opcje modułu zgodnie z Twoimi potrzebami.

## Pomoc i wsparcie

Jeśli napotkasz problemy podczas instalacji lub konfiguracji modułu, skontaktuj się z naszym działem wsparcia technicznego (https://blpaczka.com/kontakt).
